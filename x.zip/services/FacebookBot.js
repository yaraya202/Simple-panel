const fca = require('fca-priyansh');
const fs = require('fs').promises;
const path = require('path');

class FacebookBot {
    constructor(serverId, config, onLog, onError) {
        this.serverId = serverId;
        this.config = config;
        this.onLog = onLog;
        this.onError = onError;
        this.accounts = []; // Array of active accounts with apis
        this.isRunning = false;
        this.isInitializing = false;
        this.messages = [];
        this.stopping = false;
        this.automationPromise = null;
        
        // Advanced statistics tracking
        this.validCookies = 0;
        this.expiredCookies = 0;
        this.otherFailures = 0;
        this.totalMessagesSent = 0;
        
        // Multi-cookie management - more advanced than before
        this.allCookies = [];
        this.activeCookieCount = config.activeCookieCount || 1;
    }

    start() {
        // Return immediately, run entire initialization in background
        this.stopping = false;
        this.isInitializing = true;
        this.isRunning = false; // Will be set to true after successful init
        this.onLog('🔄 Starting Facebook bot with fca-priyansh...', 'info');
        
        // Run entire initialization pipeline in background (non-blocking)
        this.automationPromise = this.runInitialization().catch(error => {
            this.onError(`Initialization failed: ${error.message}`);
            this.isInitializing = false;
            this.isRunning = false;
        });
        
        // Return immediately so UI/API can respond
        return;
    }

    async runInitialization() {
        try {
            // Load messages first
            await this.loadMessages();
            
            // Check if stopping after loading messages
            if (this.stopping) {
                this.isInitializing = false;
                this.isRunning = false;
                this.onLog('⚠️ Initialization stopped during message loading', 'warning');
                return;
            }

            // Process cookies and setup accounts
            await this.processCookies();
            
            // Check if stopping after processing cookies
            if (this.stopping) {
                this.isInitializing = false;
                this.isRunning = false;
                this.onLog('⚠️ Initialization stopped during cookie processing', 'warning');
                return;
            }
            
            // Validate accounts
            if (this.accounts.length === 0) {
                this.onError('❌ No accounts logged in successfully - all cookies are expired or invalid');
                this.isInitializing = false;
                this.isRunning = false;
                return;
            }
            
            // Final check before starting automation
            if (this.stopping) {
                this.isInitializing = false;
                this.isRunning = false;
                this.onLog('⚠️ Initialization stopped before starting automation', 'warning');
                return;
            }
            
            // Log summary
            this.onLog(`📊 Cookie validation complete:`, 'info');
            this.onLog(`   ✅ Valid cookies: ${this.validCookies}`, 'success');
            this.onLog(`   ⚠️ Expired/Invalid cookies: ${this.expiredCookies}`, 'warning');
            if (this.otherFailures > 0) {
                this.onLog(`   ❌ Other failures: ${this.otherFailures}`, 'error');
            }
            
            // Mark initialization complete and start automation
            this.isInitializing = false;
            this.isRunning = true;
            this.onLog(`🚀 Starting automation with ${this.accounts.length} valid account(s)`, 'success');
            
            // Start message automation
            await this.startMessageAutomation();
            
        } catch (error) {
            this.onError(`Initialization error: ${error.message}`);
            this.isInitializing = false;
            this.isRunning = false;
            throw error;
        }
    }




    async loadMessages() {
        try {
            // Check if messages are provided directly (from paste content)
            if (this.config.messages && Array.isArray(this.config.messages)) {
                this.messages = this.config.messages.filter(msg => msg.trim().length > 0);
                this.onLog(`📝 Loaded ${this.messages.length} messages from content`, 'info');
            } else if (this.config.messageFile) {
                // Load from file (traditional method)
                const filePath = path.resolve(this.config.messageFile);
                const fileContent = await fs.readFile(filePath, 'utf8');
                
                // Split by lines and filter empty lines
                this.messages = fileContent
                    .split('\n')
                    .map(line => line.trim())
                    .filter(line => line.length > 0);
                    
                this.onLog(`📄 Loaded ${this.messages.length} messages from file`, 'info');
            } else {
                throw new Error('No messages provided - either messageFile or messages array required');
            }

            if (this.messages.length === 0) {
                throw new Error('No valid messages found');
            }
            
        } catch (error) {
            throw new Error(`Failed to load messages: ${error.message}`);
        }
    }

    async processCookies() {
        let cookieData = this.config.facebookCookie;
        
        // Handle both single cookie and multi-cookie scenarios
        if (this.config.isMultiCookie && Array.isArray(cookieData)) {
            this.onLog(`🍪 Multi-cookie mode: ${cookieData.length} cookies provided`, 'info');
            this.allCookies = cookieData;
        } else {
            this.onLog('📝 Processing single Facebook cookie...', 'info');
            this.allCookies = [cookieData.trim()];
        }

        // Ensure appstates directory exists
        await fs.mkdir('./appstates', { recursive: true }).catch(() => {});

        // Process all cookies in parallel with fca-priyansh
        this.onLog(`🔄 Validating ${this.allCookies.length} cookie(s)...`, 'info');
        
        const loginResults = await Promise.allSettled(this.allCookies.map(async (cookie, index) => {
            return await this.validateCookie(cookie, index);
        }));

        // Process results
        loginResults.forEach((result, index) => {
            if (result.status === 'fulfilled' && result.value) {
                this.accounts.push(result.value);
            }
        });
    }

    async validateCookie(cookie, index) {
        return new Promise((resolve, reject) => {
            try {
                // Convert cookie string to appState format for fca-priyansh
                const appState = this.convertCookieToAppState(cookie);
                
                // Add timeout to prevent hanging
                const timeout = setTimeout(() => {
                    this.onLog(`⚠️ Account ${index + 1}: Login timeout - skipping`, 'warning');
                    this.expiredCookies++;
                    reject(new Error('Login timeout'));
                }, 30000); // 30 second timeout

                fca({ appState }, (err, api) => {
                    clearTimeout(timeout);
                    if (err) {
                        const errorMsg = err.message || err.toString();
                        // Check if error indicates expired session/cookie
                        if (errorMsg.toLowerCase().includes('session') || 
                            errorMsg.toLowerCase().includes('expired') || 
                            errorMsg.toLowerCase().includes('invalid') ||
                            errorMsg.toLowerCase().includes('token') ||
                            errorMsg.toLowerCase().includes('login') ||
                            errorMsg.toLowerCase().includes('ctx') ||
                            errorMsg.toLowerCase().includes('appstate')) {
                            this.onLog(`⚠️ Account ${index + 1}: Cookie expired or invalid - skipping`, 'warning');
                            this.expiredCookies++;
                        } else {
                            this.onLog(`❌ Account ${index + 1}: Login error - ${errorMsg}`, 'error');
                            this.otherFailures++;
                        }
                        reject(err);
                        return;
                    }
                    try {
                        const uid = api.getCurrentUserID();
                        this.onLog(`✅ Account ${index + 1} (${uid.slice(0, 5)}...) - Login successful`, 'success');
                        this.validCookies++;
                        
                        // Save appState for future use
                        fs.writeFile(path.join('./appstates', `${uid}.json`), JSON.stringify(appState)).catch(() => {});
                        
                        resolve({ api, uid, index });
                    } catch (apiErr) {
                        this.onLog(`❌ Account ${index + 1}: Error getting user ID - ${apiErr.message || apiErr}`, 'error');
                        this.otherFailures++;
                        reject(apiErr);
                    }
                });
            } catch (fcaErr) {
                this.onLog(`❌ Account ${index + 1}: FCA initialization error - ${fcaErr.message || fcaErr}`, 'error');
                this.otherFailures++;
                reject(fcaErr);
            }
        });
    }

    convertCookieToAppState(cookieString) {
        return cookieString.split(';').map(c => {
            const trimmed = c.trim();
            const equalIndex = trimmed.indexOf('=');
            if (equalIndex === -1) return null;
            const key = trimmed.substring(0, equalIndex);
            const rawValue = trimmed.substring(equalIndex + 1);
            
            // Only decode critical cookies that need URL decoding (xs and pas contain %3A that should be :)
            let value;
            if (key === 'xs' || key === 'pas') {
                try {
                    value = decodeURIComponent(rawValue);
                } catch (e) {
                    value = rawValue; // If decoding fails, use original value
                }
            } else {
                value = rawValue; // Keep other cookies as-is
            }
            
            // Create proper appState format for fca-priyansh
            const now = new Date().toISOString();
            return {
                key: key,
                value: value,
                domain: "facebook.com",
                path: "/",
                hostOnly: false,
                creation: now,
                lastAccessed: now
            };
        }).filter(item => item !== null);
    }

    async startMessageAutomation() {
        const speedInSeconds = Math.round(this.config.speed / 1000);
        const targetName = this.config.targetName || '';
        
        // Start parallel automation for all accounts
        const sendPromises = this.accounts.map(async (account, index) => {
            const { api, uid } = account;
            let messageCount = 0;
            
            while (!this.stopping && this.isRunning) {
                for (let i = 0; i < this.messages.length; i++) {
                    if (this.stopping || !this.isRunning) break;
                    
                    messageCount++;
                    const message = targetName ? `${targetName}: ${this.messages[i]}` : this.messages[i];
                    
                    try {
                        await this.sendMessage(api, message, this.config.groupTid);
                        this.onLog(`Account ${index + 1} (${uid.slice(0, 5)}...) sent message #${messageCount}: "${this.messages[i]}"`, 'success');
                        this.totalMessagesSent++;
                    } catch (err) {
                        this.onLog(`Account ${index + 1} (${uid.slice(0, 5)}...) error sending message #${messageCount}: ${err.message || err}`, 'error');
                    }
                    
                    if (!this.stopping && this.isRunning) {
                        this.onLog(`Account ${index + 1} waiting ${speedInSeconds} seconds before next message...`, 'info');
                        await new Promise(resolve => setTimeout(resolve, this.config.speed));
                    }
                }
                
                if (!this.stopping && this.isRunning && this.messages.length > 0) {
                    this.onLog(`Account ${index + 1} completed one cycle, starting again...`, 'info');
                }
            }
            
            this.onLog(`Account ${index + 1} (${uid.slice(0, 5)}...) stopped after sending ${messageCount} messages`, 'warning');
        });

        // Wait for all accounts to complete
        await Promise.allSettled(sendPromises);
        this.onLog(`🏁 Automation completed. Total messages sent: ${this.totalMessagesSent}`, 'success');
    }

    async sendMessage(api, message, groupTid) {
        return new Promise((resolve, reject) => {
            api.sendMessage(message, groupTid, (err, messageInfo) => {
                if (err) reject(err);
                else resolve(messageInfo);
            });
        });
    }

    stop() {
        this.stopping = true;
        this.isRunning = false;
        this.isInitializing = false;
        
        // Logout all active accounts
        this.accounts.forEach((account, index) => {
            try {
                if (account.api && account.api.logout) {
                    account.api.logout();
                    this.onLog(`🔓 Account ${index + 1} logged out`, 'info');
                }
            } catch (error) {
                this.onLog(`⚠️ Error logging out account ${index + 1}: ${error.message}`, 'warning');
            }
        });
        
        this.accounts = [];
        this.automationPromise = null;
        this.onLog('🛑 Bot stopped - All accounts disconnected', 'warning');
    }

    restart() {
        this.onLog('🔄 Restarting bot...', 'info');
        this.stop();
        
        // Wait a moment before restarting
        setTimeout(() => {
            this.start(); // start() is now synchronous, errors handled via onError
        }, 2000);
    }

    getStatus() {
        const basicStatus = {
            isRunning: this.isRunning,
            isInitializing: this.isInitializing,
            messagesLoaded: this.messages.length,
            totalMessagesSent: this.totalMessagesSent,
            activeAccounts: this.accounts.length,
            validCookies: this.validCookies,
            expiredCookies: this.expiredCookies,
            otherFailures: this.otherFailures,
            allCookies: this.allCookies.length
        };

        // Add account details if available
        if (this.accounts && this.accounts.length > 0) {
            basicStatus.accountDetails = this.accounts.map((account, index) => ({
                accountIndex: index + 1,
                uid: account.uid ? account.uid.slice(0, 8) + '...' : 'Unknown',
                isActive: !!account.api
            }));
        }

        return basicStatus;
    }

}

module.exports = FacebookBot;