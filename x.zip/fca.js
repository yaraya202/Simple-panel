const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const multer = require('multer');
const fca = require('fca-priyansh');
const fs = require('fs/promises');
const path = require('path');

// Add global error handlers to prevent crashes
process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

const app = express();
const server = http.createServer(app);
const io = socketIo(server);
const upload = multer({ dest: 'uploads/' });

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

let stopping = false;

const html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FB Messenger Automation Dashboard</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #333;
            overflow-x: hidden;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            text-align: center;
            margin-bottom: 40px;
            padding: 30px 0;
        }

        .header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            color: white;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
            margin-bottom: 10px;
        }

        .header p {
            font-size: 1.1rem;
            color: rgba(255,255,255,0.9);
            font-weight: 300;
        }

        .dashboard-card {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            backdrop-filter: blur(10px);
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
            font-size: 0.95rem;
        }

        .form-input, .form-select, .form-textarea {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #e1e8ed;
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }

        .form-input:focus, .form-select:focus, .form-textarea:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-textarea {
            min-height: 120px;
            resize: vertical;
            font-family: inherit;
        }

        .file-upload-wrapper {
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: 100%;
        }

        .file-upload-input {
            position: absolute;
            left: -9999px;
            opacity: 0;
        }

        .file-upload-label {
            display: block;
            padding: 15px 20px;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border: 2px dashed #dee2e6;
            border-radius: 12px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            color: #666;
        }

        .file-upload-label:hover {
            background: linear-gradient(135deg, #e9ecef 0%, #dee2e6 100%);
            border-color: #667eea;
        }

        .file-name {
            margin-top: 8px;
            font-size: 0.9rem;
            color: #28a745;
            font-weight: 500;
        }

        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 18px 30px;
            border: none;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(102, 126, 234, 0.4);
        }

        .btn-danger {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%);
            color: white;
            box-shadow: 0 8px 20px rgba(255, 107, 107, 0.3);
        }

        .btn-danger:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(255, 107, 107, 0.4);
        }

        .logs-container {
            background: #2d3748;
            border-radius: 12px;
            padding: 25px;
            max-height: 400px;
            overflow-y: auto;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            margin-top: 20px;
        }

        .logs-container h3 {
            color: #a0aec0;
            margin-bottom: 15px;
            font-size: 1.1rem;
        }

        .logs-container p {
            color: #e2e8f0;
            margin-bottom: 8px;
            padding: 5px 10px;
            border-left: 3px solid #667eea;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 4px;
            font-size: 0.9rem;
        }

        .status-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            background: #28a745;
            border-radius: 50%;
            margin-right: 8px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(40, 167, 69, 0.7); }
            70% { box-shadow: 0 0 0 10px rgba(40, 167, 69, 0); }
            100% { box-shadow: 0 0 0 0 rgba(40, 167, 69, 0); }
        }

        .hidden {
            display: none !important;
        }

        .success-modal {
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 20px 25px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(40, 167, 69, 0.3);
            z-index: 1000;
            transform: translateX(400px);
            transition: transform 0.3s ease;
        }

        .success-modal.show {
            transform: translateX(0);
        }

        .row {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }

        .col-half {
            flex: 1;
        }

        @media (max-width: 768px) {
            .row {
                flex-direction: column;
            }

            .button-group {
                flex-direction: column;
            }

            .container {
                padding: 15px;
            }

            .dashboard-card {
                padding: 25px;
            }
        }

        .loading-spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
            display: inline-block;
            margin-right: 10px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><span class="status-indicator"></span>Facebook Messenger Automation</h1>
            <p>Professional Bot Management Dashboard</p>
        </div>

        <div class="dashboard-card">
            <form id="configForm">
                <div class="row">
                    <div class="col-half">
                        <div class="form-group">
                            <label class="form-label" for="serverName">Server Name</label>
                            <input type="text" id="serverName" class="form-input" placeholder="Enter server name" required>
                        </div>
                    </div>
                    <div class="col-half">
                        <div class="form-group">
                            <label class="form-label" for="tid">Target Group ID</label>
                            <input type="text" id="tid" class="form-input" placeholder="Facebook group TID" required>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-half">
                        <div class="form-group">
                            <label class="form-label" for="speed">Message Interval (seconds)</label>
                            <input type="number" id="speed" class="form-input" placeholder="Speed in seconds" min="1" max="300" required>
                        </div>
                    </div>
                    <div class="col-half">
                        <div class="form-group">
                            <label class="form-label" for="haterName">Bot Identifier</label>
                            <input type="text" id="haterName" class="form-input" placeholder="Bot name prefix" required>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="cookieType">Authentication Method</label>
                    <select id="cookieType" class="form-select">
                        <option value="single">Single Account Cookie</option>
                        <option value="multi">Multiple Accounts File</option>
                    </select>
                </div>

                <div class="form-group">
                    <div id="singleCookie" class="hidden">
                        <label class="form-label">Account Cookie</label>
                        <textarea id="singleCookieInput" class="form-textarea" placeholder="Paste Facebook account cookie here..."></textarea>
                    </div>

                    <div id="multiCookieFile" class="hidden">
                        <label class="form-label">Upload Cookie File</label>
                        <div class="file-upload-wrapper">
                            <input type="file" id="multiCookieFileInput" class="file-upload-input" accept=".txt">
                            <label for="multiCookieFileInput" class="file-upload-label">
                                📁 Click to select cookie file (.txt)
                            </label>
                        </div>
                        <div id="multiCookieName" class="file-name"></div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="messageType">Message Source</label>
                    <select id="messageType" class="form-select">
                        <option value="paste">Type Messages</option>
                        <option value="file">Upload Message File</option>
                    </select>
                </div>

                <div class="form-group">
                    <div id="messagesPaste" class="hidden">
                        <label class="form-label">Messages</label>
                        <textarea id="messagesPasteInput" class="form-textarea" placeholder="Enter messages, one per line..."></textarea>
                    </div>

                    <div id="messagesFile" class="hidden">
                        <label class="form-label">Upload Message File</label>
                        <div class="file-upload-wrapper">
                            <input type="file" id="messagesFileInput" class="file-upload-input" accept=".txt">
                            <label for="messagesFileInput" class="file-upload-label">
                                📄 Click to select message file (.txt)
                            </label>
                        </div>
                        <div id="messagesFileName" class="file-name"></div>
                    </div>
                </div>

                <div class="button-group">
                    <button type="submit" class="btn btn-primary">
                        <span id="runBtnText">🚀 Start Automation</span>
                    </button>
                    <button type="button" id="stop" class="btn btn-danger">
                        ⏹️ Stop Automation
                    </button>
                </div>
            </form>
        </div>

        <div class="dashboard-card">
            <div class="logs-container">
                <h3>📊 Real-time Activity Logs</h3>
                <div id="logs"></div>
            </div>
        </div>
    </div>

    <div id="modal" class="success-modal">
        ✅ Automation Started Successfully!
    </div>
    <script src="/socket.io/socket.io.js"></script>
    <script>
        let isRunning = false;
        const socket = io();

        socket.on('log', (msg) => {
            const logsDiv = document.getElementById('logs');
            const p = document.createElement('p');
            p.textContent = new Date().toLocaleTimeString() + ' - ' + msg;
            logsDiv.appendChild(p);
            logsDiv.scrollTop = logsDiv.scrollHeight;

            // Keep only last 100 log entries
            while (logsDiv.children.length > 100) {
                logsDiv.removeChild(logsDiv.firstChild);
            }
        });

        const form = document.getElementById('configForm');
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            if (isRunning) return;

            const runBtn = document.getElementById('runBtnText');
            const originalText = runBtn.innerHTML;
            runBtn.innerHTML = '<div class="loading-spinner"></div>Starting...';
            isRunning = true;

            try {
                const formData = new FormData();
                formData.append('serverName', document.getElementById('serverName').value);
                const cookieType = document.getElementById('cookieType').value;
                formData.append('cookieType', cookieType);

                if (cookieType === 'single') {
                    formData.append('cookie', document.getElementById('singleCookieInput').value);
                } else {
                    formData.append('cookieFile', document.getElementById('multiCookieFileInput').files[0]);
                }

                formData.append('tid', document.getElementById('tid').value);
                formData.append('speedSeconds', document.getElementById('speed').value);
                formData.append('haterName', document.getElementById('haterName').value);
                const messageType = document.getElementById('messageType').value;
                formData.append('messageType', messageType);

                if (messageType === 'paste') {
                    formData.append('messages', document.getElementById('messagesPasteInput').value);
                } else {
                    formData.append('messagesFile', document.getElementById('messagesFileInput').files[0]);
                }

                const response = await fetch('/start', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.success) {
                    showSuccessModal();
                    runBtn.innerHTML = '⏸️ Running...';
                } else {
                    runBtn.innerHTML = originalText;
                    isRunning = false;
                    alert('Failed to start automation. Check logs for details.');
                }
            } catch (error) {
                runBtn.innerHTML = originalText;
                isRunning = false;
                alert('Error: ' + error.message);
            }
        });

        document.getElementById('cookieType').addEventListener('change', (e) => {
            const singleDiv = document.getElementById('singleCookie');
            const multiDiv = document.getElementById('multiCookieFile');

            if (e.target.value === 'single') {
                singleDiv.classList.remove('hidden');
                multiDiv.classList.add('hidden');
                document.getElementById('multiCookieName').textContent = '';
            } else {
                singleDiv.classList.add('hidden');
                multiDiv.classList.remove('hidden');
            }
        });

        document.getElementById('messageType').addEventListener('change', (e) => {
            const pasteDiv = document.getElementById('messagesPaste');
            const fileDiv = document.getElementById('messagesFile');

            if (e.target.value === 'paste') {
                pasteDiv.classList.remove('hidden');
                fileDiv.classList.add('hidden');
                document.getElementById('messagesFileName').textContent = '';
            } else {
                pasteDiv.classList.add('hidden');
                fileDiv.classList.remove('hidden');
            }
        });

        document.getElementById('multiCookieFileInput').addEventListener('change', (e) => {
            const nameDiv = document.getElementById('multiCookieName');
            if (e.target.files[0]) {
                nameDiv.textContent = '✅ ' + e.target.files[0].name;
                nameDiv.style.color = '#28a745';
            } else {
                nameDiv.textContent = '';
            }
        });

        document.getElementById('messagesFileInput').addEventListener('change', (e) => {
            const nameDiv = document.getElementById('messagesFileName');
            if (e.target.files[0]) {
                nameDiv.textContent = '✅ ' + e.target.files[0].name;
                nameDiv.style.color = '#28a745';
            } else {
                nameDiv.textContent = '';
            }
        });

        document.getElementById('stop').addEventListener('click', async () => {
            try {
                await fetch('/stop', { method: 'POST' });
                const runBtn = document.getElementById('runBtnText');
                runBtn.innerHTML = '🚀 Start Automation';
                isRunning = false;
            } catch (error) {
                alert('Error stopping automation: ' + error.message);
            }
        });

        function showSuccessModal() {
            const modal = document.getElementById('modal');
            modal.classList.add('show');
            setTimeout(() => {
                modal.classList.remove('show');
            }, 4000);
        }

        // Connection status indicator
        socket.on('connect', () => {
            const indicator = document.querySelector('.status-indicator');
            indicator.style.background = '#28a745';
        });

        socket.on('disconnect', () => {
            const indicator = document.querySelector('.status-indicator');
            indicator.style.background = '#dc3545';
        });

        socket.on('automation_done', () => {
            const runBtn = document.getElementById('runBtnText');
            runBtn.innerHTML = '🚀 Start Automation';
            isRunning = false;
        });

        // Initialize form state
        document.getElementById('cookieType').dispatchEvent(new Event('change'));
        document.getElementById('messageType').dispatchEvent(new Event('change'));

        // Add welcome message
        setTimeout(() => {
            const logsDiv = document.getElementById('logs');
            const p = document.createElement('p');
            p.textContent = new Date().toLocaleTimeString() + ' - 🎯 Dashboard ready! Configure settings above to start automation.';
            p.style.color = '#20c997';
            logsDiv.appendChild(p);
        }, 1000);
    </script>
</body>
</html>
`;

app.get('/', (req, res) => {
    res.send(html);
});

app.post('/start', upload.fields([{ name: 'cookieFile', maxCount: 1 }, { name: 'messagesFile', maxCount: 1 }]), async (req, res) => {
    try {
        stopping = false;
    const { serverName, cookieType, tid, speedSeconds, haterName, messageType, cookie, messages } = req.body;
    let cookies = [];
    if (cookieType === 'single') {
        if (cookie) cookies = [cookie];
    } else if (req.files['cookieFile']) {
        const filePath = req.files['cookieFile'][0].path;
        const content = await fs.readFile(filePath, 'utf8');
        cookies = content.split('\n').map(line => line.trim()).filter(line => line);
        await fs.unlink(filePath);
    }
    let msgs = [];
    if (messageType === 'paste') {
        if (messages) msgs = messages.split('\n').map(line => line.trim()).filter(line => line);
    } else if (req.files['messagesFile']) {
        const filePath = req.files['messagesFile'][0].path;
        const content = await fs.readFile(filePath, 'utf8');
        msgs = content.split('\n').map(line => line.trim()).filter(line => line);
        await fs.unlink(filePath);
    }
    if (cookies.length === 0) {
        io.emit('log', 'Error: No cookies provided');
        return res.json({ success: false, error: 'No cookies provided' });
    }
    if (msgs.length === 0) {
        io.emit('log', 'Error: No messages provided');
        return res.json({ success: false, error: 'No messages provided' });
    }
    const speed = parseInt(speedSeconds) || 5;
    if (speed < 1 || speed > 300) {
        io.emit('log', 'Error: Message speed must be between 1-300 seconds');
        return res.json({ success: false, error: 'Invalid speed range' });
    }
    io.emit('log', `Starting automation for server: ${serverName}`);
    io.emit('log', `Processing ${cookies.length} cookie(s) from ${cookieType === 'single' ? 'single input' : 'uploaded file'}...`);
    await fs.mkdir('./appstates', { recursive: true });
    const accounts = [];
    let validCookies = 0;
    let expiredCookies = 0;
    let otherFailures = 0;

    const loginResults = await Promise.allSettled(cookies.map(async (ck, index) => {
        const appState = ck.split(';').map(c => {
            const trimmed = c.trim();
            const equalIndex = trimmed.indexOf('=');
            if (equalIndex === -1) return null;
            const key = trimmed.substring(0, equalIndex);
            const rawValue = trimmed.substring(equalIndex + 1);

            // Only decode critical cookies that need URL decoding (xs and pas contain %3A that should be :)
            let value;
            if (key === 'xs' || key === 'pas') {
                try {
                    value = decodeURIComponent(rawValue);
                } catch (e) {
                    value = rawValue; // If decoding fails, use original value
                }
            } else {
                value = rawValue; // Keep other cookies as-is
            }

            // Create proper appState format for fca-priyansh
            const now = new Date().toISOString();
            return {
                key: key,
                value: value,
                domain: "facebook.com",
                path: "/",
                hostOnly: false,
                creation: now,
                lastAccessed: now
            };
        }).filter(item => item !== null);
        return new Promise((resolve, reject) => {
            try {
                // Add timeout to prevent hanging
                const timeout = setTimeout(() => {
                    io.emit('log', `⚠️ Account ${index + 1}: Login timeout - skipping`);
                    expiredCookies++;
                    reject(new Error('Login timeout'));
                }, 30000); // 30 second timeout

                fca({ appState }, (err, api) => {
                    clearTimeout(timeout);
                    if (err) {
                        const errorMsg = err.message || err.toString();
                        // Check if error indicates expired session/cookie
                        if (errorMsg.toLowerCase().includes('session') || 
                            errorMsg.toLowerCase().includes('expired') || 
                            errorMsg.toLowerCase().includes('invalid') ||
                            errorMsg.toLowerCase().includes('token') ||
                            errorMsg.toLowerCase().includes('login') ||
                            errorMsg.toLowerCase().includes('ctx') ||
                            errorMsg.toLowerCase().includes('appstate')) {
                            io.emit('log', `⚠️ Account ${index + 1}: Cookie expired or invalid - skipping`);
                            expiredCookies++;
                        } else {
                            io.emit('log', `❌ Account ${index + 1}: Login error - ${errorMsg}`);
                            otherFailures++;
                        }
                        reject(err);
                        return;
                    }
                    try {
                        const uid = api.getCurrentUserID();
                        io.emit('log', `✅ Account ${index + 1} (${uid.slice(0, 5)}...) - Login successful`);
                        validCookies++;
                        fs.writeFile(path.join('./appstates', `${uid}.json`), JSON.stringify(appState)).catch(() => {});
                        accounts.push({ api, uid });
                        resolve();
                    } catch (apiErr) {
                        io.emit('log', `❌ Account ${index + 1}: Error getting user ID - ${apiErr.message || apiErr}`);
                        otherFailures++;
                        reject(apiErr);
                    }
                });
            } catch (fcaErr) {
                io.emit('log', `❌ Account ${index + 1}: FCA initialization error - ${fcaErr.message || fcaErr}`);
                otherFailures++;
                reject(fcaErr);
            }
        });
    }));

    // Provide detailed summary of cookie validation results
    io.emit('log', `📊 Cookie validation complete:`);
    io.emit('log', `   ✅ Valid cookies: ${validCookies}`);
    io.emit('log', `   ⚠️ Expired/Invalid cookies: ${expiredCookies}`);
    if (otherFailures > 0) {
        io.emit('log', `   ❌ Other failures: ${otherFailures}`);
    }

    if (accounts.length === 0) {
        io.emit('log', '❌ No accounts logged in successfully - all cookies are expired or invalid');
        return res.json({ success: false, error: 'All cookies are expired or invalid' });
    }

    io.emit('log', `🚀 Starting automation with ${accounts.length} valid account(s)`);
    const sendPromises = accounts.map(async (acc, index) => {
        const { api, uid } = acc;
        let messageCount = 0;
        while (!stopping) {
            for (let i = 0; i < msgs.length; i++) {
                if (stopping) break;
                messageCount++;
                const msg = `${haterName} ${msgs[i]}`;
                try {
                    await new Promise((resolve, reject) => {
                        api.sendMessage(msg, tid, (err, messageInfo) => {
                            if (err) reject(err);
                            else resolve(messageInfo);
                        });
                    });
                    io.emit('log', `Account ${index + 1} (${uid.slice(0, 5)}...) sent message #${messageCount}: "${msgs[i]}"`);
                } catch (err) {
                    io.emit('log', `Account ${index + 1} (${uid.slice(0, 5)}...) error sending message #${messageCount}: ${err.message || err}`);
                }
                if (!stopping) {
                    io.emit('log', `Account ${index + 1} waiting ${speed} seconds before next message...`);
                    await new Promise(resolve => setTimeout(resolve, speed * 1000));
                }
            }
            if (!stopping && msgs.length > 0) {
                io.emit('log', `Account ${index + 1} completed one cycle, starting again...`);
            }
        }
        io.emit('log', `Account ${index + 1} (${uid.slice(0, 5)}...) stopped after sending ${messageCount} messages`);
    });
    Promise.allSettled(sendPromises).then(() => {
        io.emit('log', 'Automation completed or stopped');
        io.emit('automation_done', { completed: true });
    });
    res.json({ success: true });
    } catch (error) {
        io.emit('log', `❌ Server error: ${error.message || error}`);
        console.error('Server error in /start:', error);
        res.json({ success: false, error: 'Server error occurred' });
    }
});

app.post('/stop', (req, res) => {
    stopping = true;
    io.emit('log', 'Stopping automation');
    res.json({ success: true });
});

server.listen(5000, '0.0.0.0', () => {
    console.log('Server running on port 5000');
});