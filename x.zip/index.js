const express = require('express');
const http = require('http');
// const https = require('https'); // SSL removed for local dev
const fs = require('fs');
const socketIo = require('socket.io');
const path = require('path');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const axios = require('axios');

// Add global error handlers to prevent crashes
process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

const app = express();

const PORT = process.env.PORT || 2500;
const BASE_PATH = process.env.BASE_PATH || '';
const IS_EXTERNAL_HOST = process.env.NODE_ENV === 'production' || process.env.EXTERNAL_HOST === 'true';

// Asset cache configuration for consistent deployment behavior
const ASSET_MAX_AGE = process.env.ASSET_MAX_AGE || 86400; // seconds (24 hours)

function setAssetHeaders(res, type) {
  // Only set headers if they haven't been sent yet
  if (!res.headersSent) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    const cache = `public, max-age=${ASSET_MAX_AGE}`;

    if (type === 'css') {
      res.setHeader('Content-Type', 'text/css; charset=utf-8');
    } else if (type === 'js') {
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    }

    res.setHeader('Cache-Control', cache);
    res.setHeader('X-Content-Type-Options', 'nosniff');
  }
}

// Middleware
app.set('trust proxy', 1);

const isProduction = process.env.NODE_ENV === 'production';

// SSL removed for local dev - HTTPS redirection disabled

// Middleware
app.use(cors({
  origin: true,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

// Add headers for external hosting compatibility
app.use((req, res, next) => {
  const protocol = 'http'; // SSL removed for local dev
  // Remove ineffective X-Forwarded-Proto header (not needed for preventing redirects)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  
  // Add additional security headers for external hosting (HTTP compatible)
  if (IS_EXTERNAL_HOST) {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'no-referrer-when-downgrade');
  }
  
  // Prevent HTTPS enforcement and clear any cached security policies
  res.removeHeader('Strict-Transport-Security');
  // Explicitly set HSTS max-age to 0 to help clear cached policies
  res.setHeader('Strict-Transport-Security', 'max-age=0');
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
    return;
  }
  next();
});

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(cookieParser());

if (isProduction || IS_EXTERNAL_HOST) {
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https:", "http:"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        connectSrc: ["'self'", "ws:", "wss:", "http:", "https:"],
        imgSrc: ["'self'", "data:", "https:", "http:"],
        fontSrc: ["'self'", "https:", "data:"],
        objectSrc: ["'none'"],
        mediaSrc: ["'self'"],
        baseUri: ["'self'"]
      }
    },
    crossOriginResourcePolicy: { policy: "cross-origin" },
    hsts: false
  }));
} else {
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        connectSrc: ["'self'", "ws:", "wss:", "http:", "https:"],
        imgSrc: ["'self'", "data:", "https:", "http:"],
        fontSrc: ["'self'", "https:", "data:"],
        objectSrc: ["'none'"],
        mediaSrc: ["'self'"]
      }
    }
  }));
}

// JSON parsing for specific routes only (not for file uploads)
app.use('/api/auth', express.json({ limit: '10mb' }));
app.use('/api/admin', express.json({ limit: '10mb' }));
app.use('/api/cookies', express.json({ limit: '10mb' }));

// URL encoded for form data
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.'
});
app.use('/api/', limiter);

// Static file middleware (removed duplicate CORS headers)
app.use((req, res, next) => {
  if (req.url.includes('/css/') || req.url.includes('/js/') || req.url.endsWith('.css') || req.url.endsWith('.js')) {
    console.log(`📁 Static file request: ${req.method} ${req.url}`);
  }

  // Set cache headers only
  if (!res.headersSent) {
    if (req.url.endsWith('.css')) {
      res.setHeader('Content-Type', 'text/css; charset=utf-8');
      res.setHeader('Cache-Control', 'public, max-age=86400');
    } else if (req.url.endsWith('.js')) {
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
      res.setHeader('Cache-Control', 'public, max-age=86400');
    } else if (req.url.match(/\.(png|jpg|jpeg|gif|ico|svg)$/)) {
      res.setHeader('Cache-Control', 'public, max-age=31536000');
    } else if (req.url.match(/\.(html|htm)$/)) {
      res.setHeader('Cache-Control', 'no-cache');
    }
  }
  next();
});

// Serve static files
const staticOptions = {
  maxAge: ASSET_MAX_AGE * 1000,
  etag: true,
  lastModified: true,
  setHeaders: (res, filePath) => {
    // Only set headers if they haven't been sent yet
    if (!res.headersSent) {
      if (filePath.endsWith('.css')) {
        res.setHeader('Content-Type', 'text/css; charset=utf-8');
      } else if (filePath.endsWith('.js')) {
        res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
      }
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Cache-Control', `public, max-age=${ASSET_MAX_AGE}`);
      res.setHeader('X-Content-Type-Options', 'nosniff');
    }
  }
};

app.use(express.static(path.join(__dirname, 'public'), staticOptions));
app.use('/js', express.static(path.join(__dirname, 'js'), staticOptions));

if (BASE_PATH) {
  app.use(BASE_PATH, express.static(path.join(__dirname, 'public'), staticOptions));
  app.use(`${BASE_PATH}/js`, express.static(path.join(__dirname, 'js'), staticOptions));
}

// Backup routes for CSS and JS files
app.get('/css/:filename', (req, res) => {
  const filename = req.params.filename;
  const filePath = path.join(__dirname, 'public', 'css', filename);
  const fs = require('fs');

  console.log(`🎨 Direct CSS route hit: ${filename}`);
  setAssetHeaders(res, 'css');

  if (fs.existsSync(filePath)) {
    try {
      const cssContent = fs.readFileSync(filePath, 'utf8');
      res.send(cssContent);
    } catch (error) {
      console.error(`🎨 Error reading CSS file:`, error);
      res.status(500).send('Error reading CSS file');
    }
  } else {
    res.status(404).send('CSS file not found');
  }
});

app.get('/js/:filename', (req, res) => {
  const filename = req.params.filename;
  const filePath = path.join(__dirname, 'js', filename);
  const fs = require('fs');

  console.log(`⚡ Direct JS route hit: ${filename}`);
  setAssetHeaders(res, 'js');

  if (fs.existsSync(filePath)) {
    try {
      const jsContent = fs.readFileSync(filePath, 'utf8');
      res.send(jsContent);
    } catch (error) {
      console.error(`⚡ Error reading JS file:`, error);
      res.status(500).send('Error reading JS file');
    }
  } else {
    res.status(404).send('JS file not found');
  }
});

// BASE_PATH backup routes
if (BASE_PATH) {
  app.get(`${BASE_PATH}/css/:filename`, (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, 'public', 'css', filename);
    const fs = require('fs');

    setAssetHeaders(res, 'css');
    if (fs.existsSync(filePath)) {
      try {
        const cssContent = fs.readFileSync(filePath, 'utf8');
        res.send(cssContent);
      } catch (error) {
        res.status(500).send('Error reading CSS file');
      }
    } else {
      res.status(404).send('CSS file not found');
    }
  });

  app.get(`${BASE_PATH}/js/:filename`, (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, 'js', filename);
    const fs = require('fs');

    setAssetHeaders(res, 'js');
    if (fs.existsSync(filePath)) {
      try {
        const jsContent = fs.readFileSync(filePath, 'utf8');
        res.send(jsContent);
      } catch (error) {
        res.status(500).send('Error reading JS file');
      }
    } else {
      res.status(404).send('JS file not found');
    }
  });
}

// HTML processing function
function processHtmlForDeployment(htmlContent) {
  if (!BASE_PATH) return htmlContent;

  const basePath = BASE_PATH.startsWith('/') ? BASE_PATH : `/${BASE_PATH}`;
  htmlContent = htmlContent.replace(/href=["']\/css\//g, `href="${basePath}/css/`);
  htmlContent = htmlContent.replace(/src=["']\/js\//g, `src="${basePath}/js/`);
  htmlContent = htmlContent.replace(/src=["']\/socket\.io\//g, `src="${basePath}/socket.io/`);

  if (!htmlContent.includes('<base href=')) {
    const baseTag = `\n    <base href="${basePath}/">`;
    const headEndIndex = htmlContent.indexOf('</head>');
    if (headEndIndex !== -1) {
      htmlContent = htmlContent.slice(0, headEndIndex) + baseTag + htmlContent.slice(headEndIndex);
    }
  }

  return htmlContent;
}

// HTML route serving
function serveHtmlFile(filename) {
  return (req, res) => {
    const filePath = path.join(__dirname, 'public', filename);
    const fs = require('fs');

    // Only set headers if they haven't been sent yet
    if (!res.headersSent) {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    }

    try {
      let htmlContent = fs.readFileSync(filePath, 'utf8');
      htmlContent = processHtmlForDeployment(htmlContent);
      res.send(htmlContent);
    } catch (error) {
      console.error(`Error reading HTML file ${filename}:`, error);
      if (!res.headersSent) {
        res.status(404).send('Page not found');
      }
    }
  };
}

// HTML routes
const htmlRoutes = [
  { path: '/', file: 'index.html' },
  { path: '/admin', file: 'admin.html' },
  { path: '/login', file: 'login.html' },
  { path: '/register', file: 'register.html' },
  { path: '/dashboard', file: 'dashboard.html' },
  { path: '/create-server', file: 'create-server.html' },
  { path: '/cookie-check', file: 'cookie-check.html' },
  { path: '/approval', file: 'approval.html' }
];

htmlRoutes.forEach(route => {
  app.get(route.path, serveHtmlFile(route.file));
});

if (BASE_PATH) {
  htmlRoutes.forEach(route => {
    const fullPath = `${BASE_PATH}${route.path}`;
    app.get(fullPath, serveHtmlFile(route.file));
  });
}

// Create HTTP server for local dev
let server;

// SSL removed for local dev - Always use HTTP server
// const sslKeyPath = process.env.SSL_KEY_PATH || '/etc/ssl/private/server.key';
// const sslCertPath = process.env.SSL_CERT_PATH || '/etc/ssl/certs/server.crt';
console.log('🔓 Creating HTTP server');
server = http.createServer(app);

const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"],
        credentials: true
    },
    path: '/socket.io/',
    transports: ['polling', 'websocket'],
    allowEIO3: true,
    pingTimeout: 60000,
    pingInterval: 25000,
    secure: false // SSL removed for local dev
});

// Make io accessible to routes (moved after io initialization)
app.set('io', io);

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'Server Manager API is running', timestamp: new Date().toISOString() });
});

// Debug endpoint
app.get('/api/debug', (req, res) => {
  const fs = require('fs');
  const publicPath = path.join(__dirname, 'public');
  const cssPath = path.join(publicPath, 'css');
  const jsPath = path.join(__dirname, 'js');

  try {
    const styleCSS = path.join(cssPath, 'style.css');
    const appJS = path.join(jsPath, 'app.js');

    res.json({
      server: {
        port: PORT,
        basePath: BASE_PATH,
        env: process.env.NODE_ENV || 'development',
        platform: process.platform,
        nodeVersion: process.version,
        isProduction: process.env.NODE_ENV === 'production'
      },
      paths: {
        __dirname: __dirname,
        publicPath: publicPath,
        cssPath: cssPath,
        jsPath: jsPath
      },
      directories: {
        publicExists: fs.existsSync(publicPath),
        cssExists: fs.existsSync(cssPath),
        jsExists: fs.existsSync(jsPath),
        cssFiles: fs.existsSync(cssPath) ? fs.readdirSync(cssPath) : [],
        jsFiles: fs.existsSync(jsPath) ? fs.readdirSync(jsPath) : []
      },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Debug endpoint error',
      message: error.message
    });
  }
});

// CSS test endpoint
app.get('/api/test-css', (req, res) => {
  const cssFile = path.join(__dirname, 'public', 'css', 'style.css');
  const fs = require('fs');

  if (fs.existsSync(cssFile)) {
    res.setHeader('Content-Type', 'text/css; charset=utf-8');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.sendFile(cssFile);
  } else {
    res.status(404).json({ error: 'CSS file not found', path: cssFile });
  }
});

// COOKIE CHECKER ROUTER (from cookie.js)
const cookieRouter = express.Router();

// Function to validate required cookie keys
function validateCookie(cookieString) {
    const requiredKeys = ['c_user', 'xs'];
    const cookieLower = cookieString.toLowerCase();

    for (const key of requiredKeys) {
        if (!cookieLower.includes(key + '=')) {
            return false;
        }
    }
    return true;
}

// Function to parse cookie string to appState format
function parseCookieToAppState(cookieString) {
    try {
        if (!validateCookie(cookieString)) {
            throw new Error('Missing required cookie keys (c_user, xs)');
        }

        const cookies = cookieString.split(';').map(cookie => cookie.trim());
        const appState = [];

        cookies.forEach(cookie => {
            const equalIndex = cookie.indexOf('=');
            if (equalIndex > 0) {
                const key = cookie.substring(0, equalIndex).trim();
                const value = cookie.substring(equalIndex + 1).trim();

                if (key && value) {
                    appState.push({
                        key: key,
                        value: value,
                        domain: ".facebook.com",
                        path: "/",
                        hostOnly: false,
                        creation: new Date().toISOString(),
                        lastAccessed: new Date().toISOString()
                    });
                }
            }
        });

        return appState;
    } catch (error) {
        throw new Error('Invalid cookie format: ' + error.message);
    }
}

// Function to test a single cookie
async function testCookie(cookieString) {
    const timeout = new Promise((resolve) => {
        setTimeout(() => {
            resolve({ 
                success: false, 
                error: 'Cookie check timed out after 15 seconds',
                cookie: '***masked***'
            });
        }, 15000);
    });

    const cookieCheck = new Promise((resolve) => {
        try {
            const login = require('fca-priyansh');
            const appState = parseCookieToAppState(cookieString);

            console.log('⏰ Starting login process...');
            const loginStartTime = Date.now();

            login({ 
                appState: appState,
                pageID: "",
                selfListen: false,
                listenEvents: false,
                updatePresence: false,
                autoMarkDelivery: false,
                autoMarkRead: false
            }, (err, api) => {
                const loginTime = Date.now() - loginStartTime;
                console.log(`⏱️ Login completed in ${loginTime}ms`);
                if (err) {
                    console.error('Login error:', err);
                    resolve({ 
                        success: false, 
                        error: 'Cookie expired or invalid',
                        cookie: '***masked***'
                    });
                    return;
                }

                console.log('🔍 Extracting user ID from appstate...');
                let userID = null;

                try {
                    const cUserCookie = appState.find(cookie => cookie.key === 'c_user');
                    if (cUserCookie && cUserCookie.value) {
                        userID = cUserCookie.value;
                        console.log(`✅ Found user ID from cookie: ${userID}`);
                    }
                } catch (extractError) {
                    console.log('Error extracting user ID from appstate:', extractError);
                }

                if (!userID) {
                    console.log('🔄 Fallback: trying getCurrentUserID...');
                    const userIdTimeout = setTimeout(() => {
                        console.log('⚠️ getCurrentUserID timed out, using fallback');
                        processUserInfo(api, 'unknown', resolve);
                    }, 3000);

                    api.getCurrentUserID((err, fetchedUserID) => {
                        clearTimeout(userIdTimeout);
                        if (!err && fetchedUserID) {
                            userID = fetchedUserID;
                            console.log(`✅ getCurrentUserID success: ${userID}`);
                        }
                        processUserInfo(api, userID || 'unknown', resolve);
                    });
                } else {
                    processUserInfo(api, userID, resolve);
                }
            });

            function processUserInfo(api, userID, resolve) {
                console.log('👤 Getting user info details...');
                const userInfoStartTime = Date.now();

                api.getUserInfo(userID, (err, userInfo) => {
                    const userInfoTime = Date.now() - userInfoStartTime;
                    console.log(`⏱️ getUserInfo took ${userInfoTime}ms`);

                    if (err) {
                        console.log('getUserInfo error:', err);
                        resolve({ 
                            success: false, 
                            error: 'Failed to get user details',
                            cookie: '***masked***'
                        });
                        return;
                    }

                    try {
                        if (!userInfo || !userInfo[userID]) {
                            throw new Error('User info not available');
                        }

                        const user = userInfo[userID];
                        const name = user.name || 'Unknown User';
                        const profileUrl = user.profileUrl || '';

                        let profilePic = '';
                        if (user.profilePicLarge) {
                            profilePic = user.profilePicLarge;
                        } else if (user.picture) {
                            profilePic = user.picture;
                        } else if (user.thumbSrc) {
                            profilePic = user.thumbSrc;
                        } else if (userID && userID !== 'unknown') {
                            profilePic = `https://graph.facebook.com/${userID}/picture?type=large&width=200&height=200`;
                        }

                        console.log(`✅ Successfully retrieved info for: ${name}`);

                        resolve({
                            success: true,
                            userID: userID,
                            name: name,
                            profileUrl: profileUrl,
                            profilePic: profilePic,
                            cookie: '***masked***'
                        });
                    } catch (userError) {
                        console.log('User data extraction error:', userError);
                        resolve({
                            success: false,
                            error: 'Failed to extract user details',
                            cookie: '***masked***'
                        });
                    }
                });
            }
        } catch (error) {
            resolve({ 
                success: false, 
                error: 'Invalid cookie format',
                cookie: '***masked***'
            });
        }
    });

    return await Promise.race([cookieCheck, timeout]);
}

// Cookie checking routes
cookieRouter.post('/check-cookie', async (req, res) => {
    try {
        const { cookie } = req.body;

        if (!cookie || typeof cookie !== 'string') {
            return res.status(400).json({
                success: false,
                error: 'Cookie string is required'
            });
        }

        console.log('🚀 Starting cookie check...');
        const result = await testCookie(cookie);

        res.json(result);

    } catch (error) {
        console.error('Cookie check error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to test cookie'
        });
    }
});

cookieRouter.post('/test-reliable', async (req, res) => {
    try {
        const { cookie } = req.body;

        if (!cookie || typeof cookie !== 'string') {
            return res.status(400).json({
                error: 'Cookie string is required',
                isValid: false,
                userInfo: null
            });
        }

        console.log('🚀 Starting reliable cookie test...');
        const result = await testCookie(cookie);

        if (result.success) {
            res.json({
                isValid: true,
                userInfo: {
                    id: result.userID,
                    name: result.name,
                    profileUrl: result.profileUrl,
                    profilePic: result.profilePic
                },
                error: null
            });
        } else {
            res.json({
                isValid: false,
                userInfo: null,
                error: result.error
            });
        }

    } catch (error) {
        console.error('Reliable cookie test error:', error);
        res.status(500).json({
            error: 'Failed to test cookie',
            isValid: false,
            userInfo: null
        });
    }
});



// Mount routers
app.use('/api/cookies', cookieRouter);

// Import and use other route handlers
const { router: authRouter } = require('./routes/auth');
const { router: serverRouter } = require('./routes/servers');
const adminRouter = require('./routes/admin');

app.use('/api/auth', authRouter);
app.use('/api/servers', serverRouter);
app.use('/api/admin', adminRouter);

// Socket.IO for real-time features
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('authenticate', (token) => {
    try {
      const { verifyToken } = require('./middleware/auth');
      const decoded = verifyToken(token);
      socket.userId = decoded.userId;
      socket.join(`user-${decoded.userId}`);
      console.log(`User ${decoded.userId} authenticated and joined room`);
    } catch (error) {
      socket.emit('authError', 'Invalid token');
    }
  });

  socket.on('joinServerRoom', (serverId) => {
    if (socket.userId) {
      socket.join(`server-${serverId}`);
      console.log(`User ${socket.userId} joined server room: ${serverId}`);
    }
  });

  socket.on('leaveServerRoom', (serverId) => {
    socket.leave(`server-${serverId}`);
    console.log(`User left server room: ${serverId}`);
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server
server.listen(PORT, '0.0.0.0', () => {
    const protocol = 'HTTP'; // Always use HTTP since SSL is disabled
    const scheme = protocol.toLowerCase();
    
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📍 Local access: ${scheme}://localhost:${PORT}`);
    console.log(`🌐 External access: ${scheme}://0.0.0.0:${PORT}`);
    console.log(`🔧 Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`🔒 Protocol: ${protocol}`);
    console.log(`📡 Socket.IO path: /socket.io/`);
    console.log(`🌍 External hosting: ${IS_EXTERNAL_HOST ? 'Yes' : 'No'}`);
    
    if (IS_EXTERNAL_HOST) {
        console.log(`⚠️  Running on external host with HTTP protocol (SSL disabled)`);
    }
    
    if (BASE_PATH) {
        console.log(`🔗 Base path: ${BASE_PATH}`);
    }
});