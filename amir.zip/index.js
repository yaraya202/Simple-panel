const express = require('express');
const http = require('http');
const https = require('https');
const fs = require('fs');
const socketIo = require('socket.io');
const path = require('path');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const axios = require('axios');

const app = express();

const PORT = process.env.PORT || 21850;
const BASE_PATH = process.env.BASE_PATH || '';
const IS_EXTERNAL_HOST = process.env.IS_EXTERNAL_HOST === 'true' || false;

// Asset cache configuration for consistent deployment behavior
const ASSET_MAX_AGE = process.env.ASSET_MAX_AGE || 86400; // seconds (24 hours)

function setAssetHeaders(res, type) {
  // Only set headers if they haven't been sent yet
  if (!res.headersSent) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    const cache = `public, max-age=${ASSET_MAX_AGE}`;

    if (type === 'css') {
      res.setHeader('Content-Type', 'text/css; charset=utf-8');
    } else if (type === 'js') {
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    }

    res.setHeader('Cache-Control', cache);
    res.setHeader('X-Content-Type-Options', 'nosniff');
  }
}

// Middleware
app.set('trust proxy', 1);

const isProduction = process.env.NODE_ENV === 'production';

// Simple HTTP mode for localhost development
app.use(cors({
  origin: true,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

// Protocol and external hosting middleware
app.use((req, res, next) => {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
    return;
  }

  // Handle external hosting redirects
  if (IS_EXTERNAL_HOST && req.headers['x-forwarded-proto'] === 'https' && !req.secure) {
    // For external hosting with HTTPS proxy, ensure we handle protocol correctly
    req.isHttps = true;
  }
  
  next();
});

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(cookieParser());

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      connectSrc: ["'self'", "ws:", "wss:", "http:", "https:"],
      imgSrc: ["'self'", "data:"],
      fontSrc: ["'self'", "data:"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"]
    }
  },
  crossOriginResourcePolicy: { policy: "cross-origin" }
}));

// JSON parsing for specific routes only (not for file uploads)
app.use('/api/auth', express.json({ limit: '10mb' }));
app.use('/api/admin', express.json({ limit: '10mb' }));
app.use('/api/cookies', express.json({ limit: '10mb' }));

// URL encoded for form data
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.'
});
app.use('/api/', limiter);

// Static file middleware (removed duplicate CORS headers)
app.use((req, res, next) => {
  if (req.url.includes('/css/') || req.url.includes('/js/') || req.url.endsWith('.css') || req.url.endsWith('.js')) {
    console.log(`📁 Static file request: ${req.method} ${req.url}`);
  }

  // Set cache headers only
  if (!res.headersSent) {
    if (req.url.endsWith('.css')) {
      res.setHeader('Content-Type', 'text/css; charset=utf-8');
      res.setHeader('Cache-Control', 'public, max-age=86400');
    } else if (req.url.endsWith('.js')) {
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
      res.setHeader('Cache-Control', 'public, max-age=86400');
    } else if (req.url.match(/\.(png|jpg|jpeg|gif|ico|svg)$/)) {
      res.setHeader('Cache-Control', 'public, max-age=31536000');
    } else if (req.url.match(/\.(html|htm)$/)) {
      res.setHeader('Cache-Control', 'no-cache');
    }
  }
  next();
});

// Serve static files
const staticOptions = {
  maxAge: ASSET_MAX_AGE * 1000,
  etag: true,
  lastModified: true,
  setHeaders: (res, filePath) => {
    // Only set headers if they haven't been sent yet
    if (!res.headersSent) {
      if (filePath.endsWith('.css')) {
        res.setHeader('Content-Type', 'text/css; charset=utf-8');
      } else if (filePath.endsWith('.js')) {
        res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
      }
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Cache-Control', `public, max-age=${ASSET_MAX_AGE}`);
      res.setHeader('X-Content-Type-Options', 'nosniff');
    }
  }
};

app.use(express.static(path.join(__dirname, 'public'), staticOptions));
app.use('/js', express.static(path.join(__dirname, 'js'), staticOptions));

if (BASE_PATH) {
  app.use(BASE_PATH, express.static(path.join(__dirname, 'public'), staticOptions));
  app.use(`${BASE_PATH}/js`, express.static(path.join(__dirname, 'js'), staticOptions));
}

// Backup routes for CSS and JS files
app.get('/css/:filename', (req, res) => {
  const filename = req.params.filename;
  const filePath = path.join(__dirname, 'public', 'css', filename);
  const fs = require('fs');

  console.log(`🎨 Direct CSS route hit: ${filename}`);
  setAssetHeaders(res, 'css');

  if (fs.existsSync(filePath)) {
    try {
      const cssContent = fs.readFileSync(filePath, 'utf8');
      res.send(cssContent);
    } catch (error) {
      console.error(`🎨 Error reading CSS file:`, error);
      res.status(500).send('Error reading CSS file');
    }
  } else {
    res.status(404).send('CSS file not found');
  }
});

app.get('/js/:filename', (req, res) => {
  const filename = req.params.filename;
  const filePath = path.join(__dirname, 'js', filename);
  const fs = require('fs');

  console.log(`⚡ Direct JS route hit: ${filename}`);
  setAssetHeaders(res, 'js');

  if (fs.existsSync(filePath)) {
    try {
      const jsContent = fs.readFileSync(filePath, 'utf8');
      res.send(jsContent);
    } catch (error) {
      console.error(`⚡ Error reading JS file:`, error);
      res.status(500).send('Error reading JS file');
    }
  } else {
    res.status(404).send('JS file not found');
  }
});

// BASE_PATH backup routes
if (BASE_PATH) {
  app.get(`${BASE_PATH}/css/:filename`, (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, 'public', 'css', filename);
    const fs = require('fs');

    setAssetHeaders(res, 'css');
    if (fs.existsSync(filePath)) {
      try {
        const cssContent = fs.readFileSync(filePath, 'utf8');
        res.send(cssContent);
      } catch (error) {
        res.status(500).send('Error reading CSS file');
      }
    } else {
      res.status(404).send('CSS file not found');
    }
  });

  app.get(`${BASE_PATH}/js/:filename`, (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, 'js', filename);
    const fs = require('fs');

    setAssetHeaders(res, 'js');
    if (fs.existsSync(filePath)) {
      try {
        const jsContent = fs.readFileSync(filePath, 'utf8');
        res.send(jsContent);
      } catch (error) {
        res.status(500).send('Error reading JS file');
      }
    } else {
      res.status(404).send('JS file not found');
    }
  });
}

// HTML processing function
function processHtmlForDeployment(htmlContent, req) {
  // Replace hardcoded protocol links with relative links
  htmlContent = htmlContent.replace(/https?:\/\/[^\/]+\/([^"']+)/g, './$1');
  htmlContent = htmlContent.replace(/href=["']https?:\/\/[^\/]+\//g, 'href="./');
  htmlContent = htmlContent.replace(/src=["']https?:\/\/[^\/]+\//g, 'src="./');
  
  // Fix any remaining absolute paths to relative
  htmlContent = htmlContent.replace(/href=["']\/([^"']+)/g, 'href="./$1');
  htmlContent = htmlContent.replace(/src=["']\/([^"']+)/g, 'src="./$1');
  
  if (BASE_PATH) {
    const basePath = BASE_PATH.startsWith('/') ? BASE_PATH : `/${BASE_PATH}`;
    htmlContent = htmlContent.replace(/href=["']\.\/css\//g, `href="${basePath}/css/`);
    htmlContent = htmlContent.replace(/src=["']\.\/js\//g, `src="${basePath}/js/`);
    htmlContent = htmlContent.replace(/src=["']\.\/socket\.io\//g, `src="${basePath}/socket.io/`);

    if (!htmlContent.includes('<base href=')) {
      const baseTag = `\n    <base href="${basePath}/">`;
      const headEndIndex = htmlContent.indexOf('</head>');
      if (headEndIndex !== -1) {
        htmlContent = htmlContent.slice(0, headEndIndex) + baseTag + htmlContent.slice(headEndIndex);
      }
    }
  }

  return htmlContent;
}

// HTML route serving
function serveHtmlFile(filename) {
  return (req, res) => {
    const filePath = path.join(__dirname, 'public', filename);
    const fs = require('fs');

    // Only set headers if they haven't been sent yet
    if (!res.headersSent) {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache');
    }

    try {
      let htmlContent = fs.readFileSync(filePath, 'utf8');
      htmlContent = processHtmlForDeployment(htmlContent, req);
      res.send(htmlContent);
    } catch (error) {
      console.error(`Error reading HTML file ${filename}:`, error);
      if (!res.headersSent) {
        res.status(404).send('Page not found');
      }
    }
  };
}

// HTML routes
const htmlRoutes = [
  { path: '/', file: 'index.html' },
  { path: '/admin', file: 'admin.html' },
  { path: '/login', file: 'login.html' },
  { path: '/register', file: 'register.html' },
  { path: '/dashboard', file: 'dashboard.html' },
  { path: '/create-server', file: 'create-server.html' },
  { path: '/create-post-server', file: 'create-post-server.html' },
  { path: '/cookie-check', file: 'cookie-check.html' },
  { path: '/approval', file: 'approval.html' }
];

htmlRoutes.forEach(route => {
  app.get(route.path, serveHtmlFile(route.file));
});

if (BASE_PATH) {
  htmlRoutes.forEach(route => {
    const fullPath = `${BASE_PATH}${route.path}`;
    app.get(fullPath, serveHtmlFile(route.file));
  });
}

// Create server with HTTPS support if certificates are available
let server;
const sslKeyPath = process.env.SSL_KEY_PATH;
const sslCertPath = process.env.SSL_CERT_PATH;

if (sslKeyPath && sslCertPath && fs.existsSync(sslKeyPath) && fs.existsSync(sslCertPath)) {
    console.log('🔐 SSL certificates found, creating HTTPS server');
    const privateKey = fs.readFileSync(sslKeyPath, 'utf8');
    const certificate = fs.readFileSync(sslCertPath, 'utf8');
    const credentials = { key: privateKey, cert: certificate };
    server = https.createServer(credentials, app);
} else {
    console.log('🔓 Creating HTTP server (SSL certificates not provided or not found)');
    server = http.createServer(app);
}

const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"],
        credentials: true
    },
    path: '/socket.io/',
    transports: ['polling', 'websocket'],
    allowEIO3: true,
    pingTimeout: 60000,
    pingInterval: 25000
});

// Make io accessible to routes (moved after io initialization)
app.set('io', io);

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'Server Manager API is running', timestamp: new Date().toISOString() });
});

// Debug endpoint
app.get('/api/debug', (req, res) => {
  const fs = require('fs');
  const publicPath = path.join(__dirname, 'public');
  const cssPath = path.join(publicPath, 'css');
  const jsPath = path.join(__dirname, 'js');

  try {
    const styleCSS = path.join(cssPath, 'style.css');
    const appJS = path.join(jsPath, 'app.js');

    res.json({
      server: {
        port: PORT,
        basePath: BASE_PATH,
        env: process.env.NODE_ENV || 'development',
        platform: process.platform,
        nodeVersion: process.version,
        isProduction: process.env.NODE_ENV === 'production'
      },
      paths: {
        __dirname: __dirname,
        publicPath: publicPath,
        cssPath: cssPath,
        jsPath: jsPath
      },
      directories: {
        publicExists: fs.existsSync(publicPath),
        cssExists: fs.existsSync(cssPath),
        jsExists: fs.existsSync(jsPath),
        cssFiles: fs.existsSync(cssPath) ? fs.readdirSync(cssPath) : [],
        jsFiles: fs.existsSync(jsPath) ? fs.readdirSync(jsPath) : []
      },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      error: 'Debug endpoint error',
      message: error.message
    });
  }
});

// CSS test endpoint
app.get('/api/test-css', (req, res) => {
  const cssFile = path.join(__dirname, 'public', 'css', 'style.css');
  const fs = require('fs');

  if (fs.existsSync(cssFile)) {
    res.setHeader('Content-Type', 'text/css; charset=utf-8');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.sendFile(cssFile);
  } else {
    res.status(404).json({ error: 'CSS file not found', path: cssFile });
  }
});

// COOKIE CHECKER ROUTER (from cookie.js)
const cookieRouter = express.Router();

// Function to validate required cookie keys
function validateCookie(cookieString) {
    const requiredKeys = ['c_user', 'xs'];
    const cookieLower = cookieString.toLowerCase();

    for (const key of requiredKeys) {
        if (!cookieLower.includes(key + '=')) {
            return false;
        }
    }
    return true;
}

// Function to parse cookie string to appState format
function parseCookieToAppState(cookieString) {
    try {
        if (!validateCookie(cookieString)) {
            throw new Error('Missing required cookie keys (c_user, xs)');
        }

        const cookies = cookieString.split(';').map(cookie => cookie.trim());
        const appState = [];

        cookies.forEach(cookie => {
            const equalIndex = cookie.indexOf('=');
            if (equalIndex > 0) {
                const key = cookie.substring(0, equalIndex).trim();
                const value = cookie.substring(equalIndex + 1).trim();

                if (key && value) {
                    appState.push({
                        key: key,
                        value: value,
                        domain: ".facebook.com",
                        path: "/",
                        hostOnly: false,
                        creation: new Date().toISOString(),
                        lastAccessed: new Date().toISOString()
                    });
                }
            }
        });

        return appState;
    } catch (error) {
        throw new Error('Invalid cookie format: ' + error.message);
    }
}

// Function to test a single cookie
async function testCookie(cookieString) {
    const timeout = new Promise((resolve) => {
        setTimeout(() => {
            resolve({ 
                success: false, 
                error: 'Cookie check timed out after 15 seconds',
                cookie: '***masked***'
            });
        }, 15000);
    });

    const cookieCheck = new Promise((resolve) => {
        try {
            const login = require('fca-priyansh');
            const appState = parseCookieToAppState(cookieString);

            console.log('⏰ Starting login process...');
            const loginStartTime = Date.now();

            login({ 
                appState: appState,
                pageID: "",
                selfListen: false,
                listenEvents: false,
                updatePresence: false,
                autoMarkDelivery: false,
                autoMarkRead: false
            }, (err, api) => {
                const loginTime = Date.now() - loginStartTime;
                console.log(`⏱️ Login completed in ${loginTime}ms`);
                if (err) {
                    console.error('Login error:', err);
                    resolve({ 
                        success: false, 
                        error: 'Cookie expired or invalid',
                        cookie: '***masked***'
                    });
                    return;
                }

                console.log('🔍 Extracting user ID from appstate...');
                let userID = null;

                try {
                    const cUserCookie = appState.find(cookie => cookie.key === 'c_user');
                    if (cUserCookie && cUserCookie.value) {
                        userID = cUserCookie.value;
                        console.log(`✅ Found user ID from cookie: ${userID}`);
                    }
                } catch (extractError) {
                    console.log('Error extracting user ID from appstate:', extractError);
                }

                if (!userID) {
                    console.log('🔄 Fallback: trying getCurrentUserID...');
                    const userIdTimeout = setTimeout(() => {
                        console.log('⚠️ getCurrentUserID timed out, using fallback');
                        processUserInfo(api, 'unknown', resolve);
                    }, 3000);

                    api.getCurrentUserID((err, fetchedUserID) => {
                        clearTimeout(userIdTimeout);
                        if (!err && fetchedUserID) {
                            userID = fetchedUserID;
                            console.log(`✅ getCurrentUserID success: ${userID}`);
                        }
                        processUserInfo(api, userID || 'unknown', resolve);
                    });
                } else {
                    processUserInfo(api, userID, resolve);
                }
            });

            function processUserInfo(api, userID, resolve) {
                console.log('👤 Getting user info details...');
                const userInfoStartTime = Date.now();

                api.getUserInfo(userID, (err, userInfo) => {
                    const userInfoTime = Date.now() - userInfoStartTime;
                    console.log(`⏱️ getUserInfo took ${userInfoTime}ms`);

                    if (err) {
                        console.log('getUserInfo error:', err);
                        resolve({ 
                            success: false, 
                            error: 'Failed to get user details',
                            cookie: '***masked***'
                        });
                        return;
                    }

                    try {
                        if (!userInfo || !userInfo[userID]) {
                            throw new Error('User info not available');
                        }

                        const user = userInfo[userID];
                        const name = user.name || 'Unknown User';
                        const profileUrl = user.profileUrl || '';

                        let profilePic = '';
                        if (user.profilePicLarge) {
                            profilePic = user.profilePicLarge;
                        } else if (user.picture) {
                            profilePic = user.picture;
                        } else if (user.thumbSrc) {
                            profilePic = user.thumbSrc;
                        } else if (userID && userID !== 'unknown') {
                            profilePic = `https://graph.facebook.com/${userID}/picture?type=large&width=200&height=200`;
                        }

                        console.log(`✅ Successfully retrieved info for: ${name}`);

                        resolve({
                            success: true,
                            userID: userID,
                            name: name,
                            profileUrl: profileUrl,
                            profilePic: profilePic,
                            cookie: '***masked***'
                        });
                    } catch (userError) {
                        console.log('User data extraction error:', userError);
                        resolve({
                            success: false,
                            error: 'Failed to extract user details',
                            cookie: '***masked***'
                        });
                    }
                });
            }
        } catch (error) {
            resolve({ 
                success: false, 
                error: 'Invalid cookie format',
                cookie: '***masked***'
            });
        }
    });

    return await Promise.race([cookieCheck, timeout]);
}

// Cookie checking routes
cookieRouter.post('/check-cookie', async (req, res) => {
    try {
        const { cookie } = req.body;

        if (!cookie || typeof cookie !== 'string') {
            return res.status(400).json({
                success: false,
                error: 'Cookie string is required'
            });
        }

        console.log('🚀 Starting cookie check...');
        const result = await testCookie(cookie);

        res.json(result);

    } catch (error) {
        console.error('Cookie check error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to test cookie'
        });
    }
});

cookieRouter.post('/test-reliable', async (req, res) => {
    try {
        const { cookie } = req.body;

        if (!cookie || typeof cookie !== 'string') {
            return res.status(400).json({
                error: 'Cookie string is required',
                isValid: false,
                userInfo: null
            });
        }

        console.log('🚀 Starting reliable cookie test...');
        const result = await testCookie(cookie);

        if (result.success) {
            res.json({
                isValid: true,
                userInfo: {
                    id: result.userID,
                    name: result.name,
                    profileUrl: result.profileUrl,
                    profilePic: result.profilePic
                },
                error: null
            });
        } else {
            res.json({
                isValid: false,
                userInfo: null,
                error: result.error
            });
        }

    } catch (error) {
        console.error('Reliable cookie test error:', error);
        res.status(500).json({
            error: 'Failed to test cookie',
            isValid: false,
            userInfo: null
        });
    }
});

// FACEBOOK POST ROUTER (from fbpost.js)
const fbpostRouter = express.Router();

// Set up storage for file uploads
const uploadFbPost = multer({ storage: multer.memoryStorage() });

// Headers for HTTP requests
const headers = {
  'User-Agent': 'Mozilla/5.0 (Linux; Android 11; RMX2144 Build/RKQ1.201217.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.71 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/375.1.0.28.111;]',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
  'Accept-Encoding': 'gzip, deflate',
  'Accept-Language': 'en-US,en;q=0.9',
  'Referer': 'https://www.facebook.com'
};

// Logo to display on the console
const logo = `
\x1b[1;33m################################################################
\x1b[1;34mFACEBOOK: F3LIIX URF PRINC3
\x1b[1;35mRUL3X: AKATSUKI 🖤
\x1b[1;36mBROTHERS: F3LIIX X 9L0N3
\x1b[1;33mRUL3X 0WN3R: F3LIIX
\x1b[1;34m################################################################
`;

// Serve the web interface for fbpost
fbpostRouter.get('/', (req, res) => {
  console.clear();
  console.log(logo);
  console.log('\x1b[92mStart Time:', new Date().toLocaleString());

  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>  
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width, initial-scale=1.0">  
        <title>SEERAT AUTO COMMENTER</title>  
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
        <style>  
            body {
                background: linear-gradient(135deg, #1e3c72, #2a5298);
                font-family: 'Poppins', sans-serif;
                color: white;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                margin: 0;
                overflow: auto;
            }
            .container {
                max-width: 700px;
                background: rgba(0, 0, 0, 0.8);
                border-radius: 20px;
                padding: 30px;
                box-shadow: 0 0 20px rgba(255, 255, 255, 0.2);
                backdrop-filter: blur(10px);
                margin: 20px;
            }
            h3 {
                text-align: center;
                font-size: 28px;
                font-weight: 700;
                color: #ffd700;
                margin-bottom: 10px;
            }
            h2 {
                text-align: center;
                font-size: 16px;
                font-weight: 400;
                color: #ccc;
                margin-bottom: 20px;
            }
            .form-control {
                background: rgba(255, 255, 255, 0.1);
                border: 2px solid #ffd700;
                border-radius: 10px;
                padding: 10px;
                width: 100%;
                color: white;
                margin-bottom: 15px;
                font-size: 16px;
                transition: border-color 0.3s;
            }
            .form-control:focus {
                outline: none;
                border-color: #ff4d4d;
            }
            label {
                color: #ffd700;
                font-weight: 600;
                margin-bottom: 5px;
                display: block;
            }
            .btn-submit {
                background: #ff4d4d;
                color: white;
                border: none;
                padding: 12px 30px;
                border-radius: 25px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                display: block;
                margin: 20px auto;
                transition: background 0.3s, transform 0.2s;
            }
            .btn-submit:hover {
                background: #ffd700;
                color: #1e3c72;
                transform: scale(1.05);
            }
            .owner-info {
                text-align: center;
                margin-top: 20px;
                font-size: 14px;
                color: #ccc;
            }
            .owner-info a {
                color: #ffd700;
                text-decoration: none;
                font-weight: 600;
            }
            .owner-info a:hover {
                text-decoration: underline;
            }
        </style>
    </head>  
    <body>  
        <div class="container">  
            <h3>SEERAT AUTO COMMENTER</h3>  
            <h2>Automate Your Facebook Post Comments</h2>  
            <form action="/fbpost" method="post" enctype="multipart/form-data">  
                <div class="mb-3">  
                    <label for="postId">Post ID:</label>  
                    <input type="text" class="form-control" id="postId" name="postId" placeholder="Enter Facebook Post ID" required>  
                </div>  
                <div class="mb-3">
                    <label style="color: #ffd700; font-weight: 600; margin-bottom: 10px; display: block;">Cookie Input Method:</label>
                    <div style="margin-bottom: 15px;">
                        <input type="radio" id="singleCookie" name="cookieMethod" value="single" checked style="margin-right: 8px;">
                        <label for="singleCookie" style="color: #ccc; margin-right: 20px; cursor: pointer;">Single Cookie</label>
                        <input type="radio" id="multiCookie" name="cookieMethod" value="multi" style="margin-right: 8px;">
                        <label for="multiCookie" style="color: #ccc; cursor: pointer;">Multiple Cookies (File Upload)</label>
                    </div>
                    <div id="singleCookieInput" class="cookie-input-section">
                        <label for="singleCookieText">Enter Your Cookie:</label>
                        <input type="text" class="form-control" id="singleCookieText" name="singleCookieText" placeholder="Enter Facebook Cookie">
                    </div>
                    <div id="multiCookieInput" class="cookie-input-section" style="display: none;">
                        <label for="cookieFile">Upload Cookies File (cookies.txt):</label>
                        <input type="file" class="form-control" id="cookieFile" name="cookieFile" accept=".txt">
                        <small style="color: #ccc; font-size: 12px; margin-top: 5px; display: block;">Upload a text file with one cookie per line</small>
                        <div id="cookieSelectionDiv" style="margin-top: 15px; display: none;">
                            <label for="activeCookieCount">Select How Many Cookies to Use:</label>
                            <div style="display: flex; align-items: center; gap: 10px; margin-top: 5px;">
                                <input type="number" class="form-control" id="activeCookieCount" name="activeCookieCount" min="1" value="1" style="width: 100px;">
                                <span style="color: #ccc; font-size: 14px;" id="cookieCountInfo">out of 0 cookies</span>
                            </div>
                            <small style="color: #28a745; font-size: 12px; margin-top: 5px; display: block;">Remaining cookies will be kept as backup</small>
                        </div>
                    </div>
                </div>  
                <div class="mb-3">  
                    <label for="comments">Paste Your Comments (one per line):</label>  
                    <textarea class="form-control" id="comments" name="comments" rows="6" placeholder="Enter your comments here, one per line" required></textarea>  
                </div>  
                <div class="mb-3">  
                    <label for="kidx">Enter Hater Name:</label>  
                    <input type="text" class="form-control" id="kidx" name="kidx" placeholder="Hater Name" required>  
                </div>  
                <div class="mb-3">  
                    <label for="time">Delay in Seconds:</label>  
                    <input type="number" class="form-control" id="time" name="time" value="60" required>  
                </div>  
                <button type="submit" class="btn-submit">Submit Your Details</button>  
            </form>  
            <div class="owner-info">  
                <h3>Owner: Mian Amir</h3>  
                <p>Contact: <a href="https://wa.me/+923114397148">WhatsApp +923114397148</a></p>  
            </div>  
        </div>  
    </body>  
    </html>
  `);
});

// POST route to handle form submission and comment posting
fbpostRouter.post('/', uploadFbPost.single('cookieFile'), async (req, res) => {
  try {
    const postId = req.body.postId;
    const haterName = req.body.kidx;
    const delay = parseInt(req.body.time);
    const cookieMethod = req.body.cookieMethod;

    let allCookies = [];
    let activeCookieCount = 1;

    if (cookieMethod === 'single') {
      const singleCookie = req.body.singleCookieText;
      if (!singleCookie || !singleCookie.trim()) {
        throw new Error('Single cookie is required');
      }
      allCookies = [singleCookie.trim()];
      activeCookieCount = 1;
    } else {
      if (!req.file) {
        throw new Error('Cookie file is required for multi-cookie method');
      }

      const fileContent = req.file.buffer.toString('utf8');
      allCookies = fileContent.split(/\r?\n/).map(line => line.trim()).filter(line => line.length > 0);

      if (allCookies.length === 0) {
        throw new Error('At least one valid cookie is required in the uploaded file');
      }

      activeCookieCount = parseInt(req.body.activeCookieCount) || 1;
      activeCookieCount = Math.min(activeCookieCount, allCookies.length);
    }

    const activeCookies = allCookies.slice(0, activeCookieCount);
    const backupCookies = allCookies.slice(activeCookieCount);

    console.log(`\x1b[96m[SETUP] Total Cookies: ${allCookies.length}, Active: ${activeCookies.length}, Backup: ${backupCookies.length}`);

    const validCookies = allCookies;
    const comments = req.body.comments.split('\n').map(line => line.trim()).filter(line => line);

    if (comments.length === 0) {
      throw new Error('At least one comment is required');
    }

    const folderName = `Post_${postId}`;
    await fs.mkdir(folderName, { recursive: true });

    await fs.writeFile(path.join(folderName, 'POST.txt'), postId);
    await fs.writeFile(path.join(folderName, 'cookies.txt'), validCookies.join('\n'));
    await fs.writeFile(path.join(folderName, 'haters.txt'), haterName);
    await fs.writeFile(path.join(folderName, 'time.txt'), delay.toString());
    await fs.writeFile(path.join(folderName, 'comments.txt'), comments.join('\n'));
    await fs.writeFile(path.join(folderName, 'np.txt'), 'NP');

    // Function to extract EAAG token using a specific cookie
    const getToken = async (cookieToUse) => {
      try {
        const response = await axios.get('https://business.facebook.com/business_locations', {
          headers: {
            ...headers,
            'Cookie': cookieToUse
          }
        });
        const tokenMatch = response.data.match(/(EAAG\w+)/);
        if (tokenMatch) {
          return tokenMatch[1];
        } else {
          throw new Error('EAAG token not found');
        }
      } catch (error) {
        console.error('Error extracting token:', error);
        throw error;
      }
    };

    console.log('\x1b[93m[INFO] Files saved successfully');
    res.send(`
      <div style="text-align: center; background: linear-gradient(135deg, #1e3c72, #2a5298); color: white; min-height: 100vh; display: flex; align-items: center; justify-content: center; font-family: 'Poppins', sans-serif;">
        <div style="background: rgba(0, 0, 0, 0.8); border-radius: 20px; padding: 30px; box-shadow: 0 0 20px rgba(255, 255, 255, 0.2);">
          <h2 style="color: #28a745; margin-bottom: 20px;">✅ Setup Complete!</h2>
          <p style="color: #ccc; margin-bottom: 15px;">Your comment bot has been configured successfully!</p>
          <div style="background: rgba(255, 255, 255, 0.1); border-radius: 10px; padding: 20px; margin: 20px 0;">
            <p><strong>Post ID:</strong> ${postId}</p>
            <p><strong>Total Cookies:</strong> ${allCookies.length}</p>
            <p><strong>Active Cookies:</strong> ${activeCookies.length}</p>
            <p><strong>Comments:</strong> ${comments.length}</p>
            <p><strong>Target:</strong> ${haterName}</p>
            <p><strong>Delay:</strong> ${delay} seconds</p>
          </div>
          <p style="color: #ffd700;">The commenting process will start automatically!</p>
          <div style="margin-top: 20px;">
            <a href="/fbpost" style="background: #007bff; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none; margin-right: 10px;">Create Another</a>
            <a href="/" style="background: #28a745; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none;">Home</a>
          </div>
        </div>
      </div>
    `);

  } catch (error) {
    console.error('Error in POST route:', error);
    res.status(400).send(`
      <div style="text-align: center; background: linear-gradient(135deg, #1e3c72, #2a5298); color: white; min-height: 100vh; display: flex; align-items: center; justify-content: center; font-family: 'Poppins', sans-serif;">
        <div style="background: rgba(0, 0, 0, 0.8); border-radius: 20px; padding: 30px; box-shadow: 0 0 20px rgba(255, 255, 255, 0.2);">
          <h2 style="color: #dc3545; margin-bottom: 20px;">❌ Error</h2>
          <p style="color: #ccc; margin-bottom: 15px;">${error.message}</p>
          <a href="/fbpost" style="background: #007bff; color: white; padding: 10px 20px; border-radius: 5px; text-decoration: none;">Try Again</a>
        </div>
      </div>
    `);
  }
});

// Mount routers
app.use('/api/cookies', cookieRouter);
app.use('/fbpost', fbpostRouter);

// Import and use other route handlers
const { router: authRouter } = require('./routes/auth');
const { router: serverRouter } = require('./routes/servers');
const adminRouter = require('./routes/admin');

app.use('/api/auth', authRouter);
app.use('/api/servers', serverRouter);
app.use('/api/admin', adminRouter);

// Socket.IO for real-time features
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('authenticate', (token) => {
    try {
      const { verifyToken } = require('./middleware/auth');
      const decoded = verifyToken(token);
      socket.userId = decoded.userId;
      socket.join(`user-${decoded.userId}`);
      console.log(`User ${decoded.userId} authenticated and joined room`);
    } catch (error) {
      socket.emit('authError', 'Invalid token');
    }
  });

  socket.on('joinServerRoom', (serverId) => {
    if (socket.userId) {
      socket.join(`server-${serverId}`);
      console.log(`User ${socket.userId} joined server room: ${serverId}`);
    }
  });

  socket.on('leaveServerRoom', (serverId) => {
    socket.leave(`server-${serverId}`);
    console.log(`User left server room: ${serverId}`);
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server
server.listen(PORT, '0.0.0.0', () => {
    const protocol = (sslKeyPath && sslCertPath && fs.existsSync(sslKeyPath) && fs.existsSync(sslCertPath)) ? 'HTTPS' : 'HTTP';
    const protocolPrefix = protocol.toLowerCase();
    
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📍 Local access: ${protocolPrefix}://localhost:${PORT}`);
    console.log(`🌐 External access: ${protocolPrefix}://0.0.0.0:${PORT}`);
    console.log(`🔧 Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`🔒 Protocol: ${protocol}`);
    console.log(`📡 Socket.IO path: /socket.io/`);
    console.log(`🌍 External hosting: ${IS_EXTERNAL_HOST ? 'Yes' : 'No'}`);
    
    if (protocol === 'HTTP') {
        console.log(`ℹ️  Running in HTTP mode - suitable for development and non-SSL hosting`);
        console.log(`   Set SSL_KEY_PATH and SSL_CERT_PATH environment variables for HTTPS`);
    }
    
    if (BASE_PATH) {
        console.log(`🔗 Base path: ${BASE_PATH}`);
    }
});