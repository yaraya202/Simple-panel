
// Utility functions for deployment compatibility
window.AppUtils = {
    // Get the correct base path for current deployment
    getBasePath: function() {
        const path = window.location.pathname;
        if (path === '/' || path.endsWith('.html')) {
            return path === '/' ? '' : path.replace(/\/[^\/]*\.html$/, '');
        }
        return path.replace(/\/$/, '');
    },
    
    // Get correct API URL
    getApiUrl: function(endpoint) {
        const basePath = this.getBasePath();
        return basePath + (endpoint.startsWith('/') ? endpoint : '/' + endpoint);
    },
    
    // Navigate to a page with correct base path
    navigateTo: function(page) {
        const basePath = this.getBasePath();
        const url = basePath + (page.startsWith('/') ? page : '/' + page);
        window.location.href = url;
    },
    
    // Make API requests with correct base path
    apiCall: async function(endpoint, options = {}) {
        const url = this.getApiUrl(endpoint);
        return fetch(url, options);
    }
};
