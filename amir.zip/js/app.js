// Initialize Socket.IO connection with proper path
const socket = io({
  path: (window.location.pathname === '/' ? '' : window.location.pathname.replace(/\/$/, '')) + '/socket.io/'
});

// DOM Elements
const loginBtn = document.getElementById('login-btn');
const registerBtn = document.getElementById('register-btn');

// Socket event listeners
socket.on('connect', () => {
    console.log('Connected to server');
});

socket.on('disconnect', () => {
    console.log('Disconnected from server');
});

// Button event listeners using AppUtils
if (loginBtn) {
    loginBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (window.AppUtils) {
            window.AppUtils.navigateTo('/login.html');
        } else {
            window.location.href = '/login.html';
        }
    });
}

if (registerBtn) {
    registerBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (window.AppUtils) {
            window.AppUtils.navigateTo('/register.html');
        } else {
            window.location.href = '/register.html';
        }
    });
}

// Test API connection using AppUtils
if (window.AppUtils) {
    window.AppUtils.apiCall('/api/health')
        .then(response => response.json())
        .then(data => {
            console.log('API Health Check:', data);
        })
        .catch(error => {
            console.error('API Error:', error);
        });
} else {
    fetch('/api/health')
        .then(response => response.json())
        .then(data => {
            console.log('API Health Check:', data);
        })
        .catch(error => {
            console.error('API Error:', error);
        });
}