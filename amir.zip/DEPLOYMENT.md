# Deployment Guide for Server Manager

This guide helps you deploy the Server Manager application to various hosting platforms like AWS, Heroku, DigitalOcean, or any other hosting service.

## Environment Variables Configuration

### Required Environment Variables

1. **BASE_PATH** (Optional but important for subdirectory deployments)
   - Set this if your app will be deployed in a subdirectory (e.g., `/app`, `/server-manager`)
   - Examples:
     - AWS Lambda with API Gateway: `BASE_PATH=/stage`
     - Shared hosting subdirectory: `BASE_PATH=/server-manager`
     - Docker with reverse proxy: `BASE_PATH=/api`

2. **NODE_ENV**
   - Set to `production` for production deployments
   - Set to `development` for development/testing

3. **PORT**
   - The port your application will run on
   - Default is 5000 if not specified

4. **ASSET_MAX_AGE** (Optional)
   - Cache duration for CSS/JS files in seconds
   - Default is 86400 (24 hours)

## Platform-Specific Deployment Instructions

### AWS Elastic Beanstalk

1. Create `.ebextensions/environment.config`:
```yaml
option_settings:
  aws:elasticbeanstalk:application:environment:
    NODE_ENV: production
    BASE_PATH: ""
    PORT: 8080
    ASSET_MAX_AGE: 86400
```

2. Deploy using EB CLI:
```bash
eb init
eb create
eb deploy
```

### AWS Lambda + API Gateway

1. Set environment variables in Lambda:
```bash
BASE_PATH=/stage  # or your API Gateway stage name
NODE_ENV=production
ASSET_MAX_AGE=86400
```

2. Use serverless framework or AWS SAM for deployment

### Heroku

1. Set environment variables:
```bash
heroku config:set NODE_ENV=production
heroku config:set BASE_PATH=""  # Leave empty for root deployment
heroku config:set ASSET_MAX_AGE=86400
```

2. Deploy:
```bash
git push heroku main
```

### DigitalOcean App Platform

1. Add environment variables in the app configuration:
```yaml
envs:
- key: NODE_ENV
  value: production
- key: BASE_PATH
  value: ""
- key: ASSET_MAX_AGE
  value: "86400"
```

### Docker Deployment

1. Create a Dockerfile:
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 5000
CMD ["node", "index.js"]
```

2. Build and run:
```bash
docker build -t server-manager .
docker run -p 5000:5000 \
  -e NODE_ENV=production \
  -e BASE_PATH="" \
  -e ASSET_MAX_AGE=86400 \
  server-manager
```

### Shared Hosting (cPanel, etc.)

If deploying to a subdirectory on shared hosting:

1. Upload files to your subdirectory (e.g., `/public_html/server-manager/`)

2. Set environment variables in your hosting control panel or `.env` file:
```
NODE_ENV=production
BASE_PATH=/server-manager
ASSET_MAX_AGE=86400
```

3. Start the application using your hosting provider's Node.js interface

## Troubleshooting CSS/Asset Loading Issues

If CSS files are not loading properly after deployment:

1. **Check BASE_PATH configuration**
   - Ensure BASE_PATH matches your deployment directory structure
   - Include leading slash but no trailing slash (e.g., `/api`, not `api/`)

2. **Verify static file routes**
   - Your app automatically creates backup routes for assets
   - Check browser developer tools for 404 errors on CSS/JS files

3. **Test asset URLs directly**
   - Try accessing `/css/style.css` directly in your browser
   - If using BASE_PATH, try `{BASE_PATH}/css/style.css`

4. **Cache issues**
   - Clear browser cache or use hard refresh (Ctrl+F5)
   - Check if proper cache headers are being sent

## Monitoring and Logs

After deployment, monitor your application:

1. **Check server logs for:**
   - CSS/JS route hits: `🎨 Direct CSS route hit` or `⚡ Direct JS route hit`
   - BASE_PATH processing: `🔧 Processing HTML with BASE_PATH`
   - Static file serving: `📁 Static file request`

2. **Browser developer tools:**
   - Network tab to verify asset loading
   - Console for JavaScript errors
   - Application/Storage tab to check if files are cached properly

## Support

If you continue to experience issues with CSS loading or deployment:

1. Check that all environment variables are set correctly
2. Verify your hosting platform supports Node.js applications
3. Ensure port 5000 (or your configured PORT) is accessible
4. Check firewall and security group settings for your hosting platform