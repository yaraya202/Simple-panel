
# 🤖 Bot Management Panel

A sleek, web-based management panel for Discord/Facebook bots with a stunning **neon blue and black theme**. Built with Node.js and Express.

![Bot Panel Preview](https://img.shields.io/badge/Status-Active-brightgreen) ![License](https://img.shields.io/badge/License-MIT-blue) ![Node.js](https://img.shields.io/badge/Node.js-16%2B-green)

## ✨ Features

### 🎨 **Neon Blue & Black Theme**
- Stunning cyberpunk-inspired design
- Glowing neon borders and buttons
- Smooth animations and transitions
- Dark background with cyan accents

### 📁 **File Management**
- **Upload & Extract**: Upload bot projects as ZIP files
- **File Browser**: Navigate through all project files
- **Code Editor**: Built-in editor with syntax highlighting
- **File Operations**: Create, edit, delete, and move files

### 🖥️ **Console & Bot Control**
- **Real-time Logs**: Live monitoring of bot output
- **Bot Lifecycle**: Start, stop, and restart bots
- **Command Runner**: Execute custom shell commands
- **Process Management**: Monitor bot status and health

### ☁️ **Cloud Ready**
- AWS compatible deployment
- Environment variable support
- Health check endpoints
- Production-ready configuration

## 🚀 Quick Start

### Installation

1. **Clone or download the project**
```bash
git clone <repository-url>
cd bot-panel
```

2. **Install dependencies**
```bash
npm install
```

3. **Start the panel**
```bash
npm start
```

4. **Access the panel**
- Open your browser and go to: `http://localhost:20930`
- Or use your server IP: `http://your-server-ip:20930`

### First Time Setup

1. **Upload your bot**: Use the Files tab to upload a ZIP file containing your bot project
2. **Manage files**: Edit configuration files, update code, or add new features
3. **Start your bot**: Use the Console tab to start and monitor your bot
4. **Monitor logs**: Watch real-time output and debug issues

## 📋 Requirements

- **Node.js**: Version 16.0.0 or higher
- **NPM**: Latest version
- **Bot Project**: Your bot should have an `index.js` file as the main entry point

## 🛠️ Configuration

### Environment Variables

```bash
PORT=20930                    # Server port (default: 20930)
NODE_ENV=production          # Environment mode
```

### Bot Requirements

Your bot project should have:
- `index.js` - Main entry file
- `package.json` - Dependencies file
- Proper error handling for graceful shutdowns

## 📂 Project Structure

```
bot-panel/
├── panel.js              # Main server file
├── package.json           # Dependencies and scripts
├── README.md             # This file
├── uploads/              # Temporary upload directory
├── bot_project/          # Extracted bot files
└── node_modules/         # NPM dependencies
```

## 🎮 Usage Guide

### **Files Tab** 📁
1. **Upload Bot Project**: Click "Upload & Extract" to upload a ZIP file
2. **Browse Files**: View all files and folders in your bot project
3. **Edit Files**: Click "Edit" to modify file contents
4. **Delete Files**: Remove unwanted files or folders

### **Console Tab** 🖥️
1. **Bot Control**: Use Start/Stop/Restart buttons to manage your bot
2. **Command Runner**: Execute shell commands in the bot directory
3. **Live Logs**: Monitor real-time output from your bot
4. **Health Status**: Check if your bot is running properly

## 🔧 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Main panel interface |
| POST | `/upload` | Upload and extract ZIP files |
| GET | `/files` | List all project files |
| GET | `/file/:path` | Get file content |
| POST | `/file/:path` | Save file content |
| DELETE | `/file/:path` | Delete file |
| POST | `/bot/start` | Start the bot |
| POST | `/bot/stop` | Stop the bot |
| POST | `/bot/restart` | Restart the bot |
| POST | `/command` | Execute shell command |
| GET | `/logs` | Get bot logs |
| GET | `/health` | Health check |

## 🌐 Deployment

### **AWS Deployment**
The panel is AWS-ready with:
- Environment variable support
- Health check endpoints
- Production optimizations
- Cross-platform compatibility

### **Manual Deployment**
1. Upload files to your server
2. Install Node.js and NPM
3. Run `npm install`
4. Start with `npm start`
5. Configure firewall for port 20930

## 🎨 Customization

### **Theme Colors**
The neon theme uses these primary colors:
- **Neon Blue**: `#00ffff` (cyan)
- **Electric Blue**: `#0080ff`
- **Deep Black**: `#000000`
- **Dark Navy**: `#1a1a2e`

### **Modify Styles**
Edit the `<style>` section in `panel.js` to customize:
- Colors and gradients
- Button styles
- Border effects
- Animations

## 🔒 Security

- File operations are restricted to the bot project directory
- Input validation on all endpoints
- Safe command execution with error handling
- No direct file system access outside project scope

## 🐛 Troubleshooting

### **Bot Won't Start**
- Ensure `index.js` exists in your bot project
- Check that all dependencies are installed
- Verify bot configuration files

### **Upload Issues**
- Ensure ZIP file contains your bot project
- Check file permissions
- Verify disk space availability

### **Connection Problems**
- Confirm port 20930 is open
- Check firewall settings
- Verify server is running

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📞 Support

If you encounter issues:
1. Check the troubleshooting section
2. Review the logs in the Console tab
3. Create an issue on GitHub

---

**Made with ⚡ and lots of ☕**

*Featuring a stunning neon blue and black cyberpunk theme that makes bot management feel like hacking in the matrix!*
