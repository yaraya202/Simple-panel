
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const { spawn, exec } = require('child_process');
const AdmZip = require('adm-zip');
const app = express();

// Configuration
const PORT = process.env.PORT || 20930;
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const BOT_DIR = path.join(__dirname, 'bot_project');

// Ensure directories exist
fs.ensureDirSync(UPLOAD_DIR);
fs.ensureDirSync(BOT_DIR);

// Store active bot process
let botProcess = null;
let botLogs = [];

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(UPLOAD_DIR));

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: UPLOAD_DIR,
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// Serve the main panel page
app.get('/', (req, res) => {
  res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bot Management Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background: linear-gradient(135deg, #000000 0%, #1a1a2e 50%, #16213e 100%);
            color: #00ffff;
        }
        .neon-border {
            border: 2px solid #00ffff;
            box-shadow: 0 0 10px #00ffff, inset 0 0 10px rgba(0, 255, 255, 0.1);
        }
        .neon-glow {
            box-shadow: 0 0 20px rgba(0, 255, 255, 0.3);
        }
        .bg-panel {
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(10px);
        }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .tab-button.active { 
            background: linear-gradient(45deg, #00ffff, #0080ff);
            color: #000;
            box-shadow: 0 0 15px #00ffff;
        }
        .tab-button {
            background: rgba(0, 0, 0, 0.7);
            border: 1px solid #00ffff;
            color: #00ffff;
            transition: all 0.3s ease;
        }
        .tab-button:hover {
            background: rgba(0, 255, 255, 0.1);
            box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
        }
        .btn-neon {
            background: linear-gradient(45deg, #00ffff, #0080ff);
            color: #000;
            border: none;
            box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
            transition: all 0.3s ease;
        }
        .btn-neon:hover {
            box-shadow: 0 0 20px rgba(0, 255, 255, 0.8);
            transform: translateY(-2px);
        }
        .btn-danger {
            background: linear-gradient(45deg, #ff0080, #ff4080);
            color: #fff;
            box-shadow: 0 0 10px rgba(255, 0, 128, 0.5);
        }
        .btn-warning {
            background: linear-gradient(45deg, #ffff00, #ff8000);
            color: #000;
            box-shadow: 0 0 10px rgba(255, 255, 0, 0.5);
        }
        .btn-success {
            background: linear-gradient(45deg, #00ff80, #00ff40);
            color: #000;
            box-shadow: 0 0 10px rgba(0, 255, 128, 0.5);
        }
        #logs { 
            height: 400px; 
            overflow-y: auto; 
            background: #000;
            border: 1px solid #00ffff;
            color: #00ff00;
        }
        #editor { 
            height: 400px; 
            background: #000;
            border: 1px solid #00ffff;
            color: #00ffff;
        }
        .file-item {
            background: rgba(0, 0, 0, 0.6);
            border: 1px solid rgba(0, 255, 255, 0.3);
            transition: all 0.3s ease;
        }
        .file-item:hover {
            border-color: #00ffff;
            box-shadow: 0 0 10px rgba(0, 255, 255, 0.3);
        }
        input, textarea {
            background: rgba(0, 0, 0, 0.8);
            border: 1px solid #00ffff;
            color: #00ffff;
        }
        input:focus, textarea:focus {
            outline: none;
            box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
        }
        .title-glow {
            text-shadow: 0 0 20px #00ffff;
            background: linear-gradient(45deg, #00ffff, #0080ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body class="min-h-screen">
    <div class="container mx-auto p-6">
        <h1 class="text-4xl font-bold mb-8 text-center title-glow">⚡ Bot Management Panel ⚡</h1>
        
        <!-- Tab Navigation -->
        <div class="flex border-b-2 border-cyan-400 mb-6">
            <button onclick="showTab('files')" class="tab-button px-6 py-3 rounded-t-lg mx-1 active">📁 Files</button>
            <button onclick="showTab('console')" class="tab-button px-6 py-3 rounded-t-lg mx-1">🖥️ Console</button>
        </div>

        <!-- Files Tab -->
        <div id="files-tab" class="tab-content active">
            <div class="bg-panel neon-border rounded-lg p-6 mb-6">
                <h2 class="text-2xl font-semibold mb-4 text-cyan-400">📤 Upload Bot Project</h2>
                <form id="uploadForm" enctype="multipart/form-data" class="space-y-4">
                    <input type="file" name="botZip" accept=".zip" class="block w-full p-3 rounded-lg">
                    <button type="submit" class="btn-neon px-6 py-3 rounded-lg font-semibold">🚀 Upload & Extract</button>
                </form>
            </div>

            <div class="bg-panel neon-border rounded-lg p-6 mb-6">
                <h2 class="text-2xl font-semibold mb-4 text-cyan-400">🗂️ File Browser</h2>
                <div id="fileBrowser" class="space-y-2"></div>
            </div>

            <div id="editor-section" class="bg-panel neon-border rounded-lg p-6" style="display: none;">
                <h2 class="text-2xl font-semibold mb-4 text-cyan-400">✏️ File Editor</h2>
                <div class="mb-4 flex flex-wrap gap-2 items-center">
                    <span id="currentFile" class="font-mono text-sm bg-black p-2 rounded border border-cyan-400"></span>
                    <button onclick="saveFile()" class="btn-success px-4 py-2 rounded font-semibold">💾 Save</button>
                    <button onclick="closeEditor()" class="btn-danger px-4 py-2 rounded font-semibold">❌ Close</button>
                </div>
                <textarea id="editor" class="w-full p-4 rounded font-mono text-sm"></textarea>
            </div>
        </div>

        <!-- Console Tab -->
        <div id="console-tab" class="tab-content">
            <div class="bg-panel neon-border rounded-lg p-6 mb-6">
                <h2 class="text-2xl font-semibold mb-4 text-cyan-400">🎮 Bot Control</h2>
                <div class="flex flex-wrap gap-4">
                    <button onclick="startBot()" class="btn-success px-6 py-3 rounded-lg font-semibold">▶️ Start Bot</button>
                    <button onclick="stopBot()" class="btn-danger px-6 py-3 rounded-lg font-semibold">⏹️ Stop Bot</button>
                    <button onclick="restartBot()" class="btn-warning px-6 py-3 rounded-lg font-semibold">🔄 Restart Bot</button>
                </div>
            </div>

            <div class="bg-panel neon-border rounded-lg p-6 mb-6">
                <h2 class="text-2xl font-semibold mb-4 text-cyan-400">⚡ Command Runner</h2>
                <div class="flex space-x-2">
                    <input type="text" id="commandInput" placeholder="Enter command..." class="flex-1 p-3 rounded-lg">
                    <button onclick="runCommand()" class="btn-neon px-6 py-3 rounded-lg font-semibold">🚀 Run</button>
                </div>
            </div>

            <div class="bg-panel neon-border rounded-lg p-6 neon-glow">
                <h2 class="text-2xl font-semibold mb-4 text-cyan-400">📊 Real-time Logs</h2>
                <div id="logs" class="p-4 rounded font-mono text-sm whitespace-pre-wrap"></div>
            </div>
        </div>
    </div>

    <script>
        let currentEditingFile = '';

        function showTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
            
            document.getElementById(tabName + '-tab').classList.add('active');
            event.target.classList.add('active');
        }

        // File Upload
        document.getElementById('uploadForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            
            try {
                const response = await fetch('/upload', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                alert(result.message);
                if (result.success) {
                    loadFiles();
                }
            } catch (error) {
                alert('Upload failed: ' + error.message);
            }
        });

        // Load file browser
        async function loadFiles() {
            try {
                const response = await fetch('/files');
                const files = await response.json();
                const browser = document.getElementById('fileBrowser');
                browser.innerHTML = '';
                
                files.forEach(file => {
                    const fileDiv = document.createElement('div');
                    fileDiv.className = 'file-item flex items-center justify-between p-3 rounded-lg';
                    fileDiv.innerHTML = \`
                        <span class="font-mono text-sm text-cyan-300">\${file.isFile ? '📄' : '📁'} \${file.path}</span>
                        <div class="flex gap-2">
                            \${file.isFile ? \`<button onclick="editFile('\${file.path}')" class="btn-neon px-3 py-1 rounded text-xs font-semibold">✏️ Edit</button>\` : ''}
                            <button onclick="deleteFile('\${file.path}')" class="btn-danger px-3 py-1 rounded text-xs font-semibold">🗑️ Delete</button>
                        </div>
                    \`;
                    browser.appendChild(fileDiv);
                });
            } catch (error) {
                console.error('Failed to load files:', error);
            }
        }

        // Edit file
        async function editFile(filePath) {
            try {
                const response = await fetch(\`/file/\${encodeURIComponent(filePath)}\`);
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('currentFile').textContent = filePath;
                    document.getElementById('editor').value = data.content;
                    document.getElementById('editor-section').style.display = 'block';
                    currentEditingFile = filePath;
                }
            } catch (error) {
                alert('Failed to load file: ' + error.message);
            }
        }

        // Save file
        async function saveFile() {
            if (!currentEditingFile) return;
            
            try {
                const response = await fetch(\`/file/\${encodeURIComponent(currentEditingFile)}\`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ content: document.getElementById('editor').value })
                });
                const result = await response.json();
                alert(result.message);
            } catch (error) {
                alert('Save failed: ' + error.message);
            }
        }

        // Close editor
        function closeEditor() {
            document.getElementById('editor-section').style.display = 'none';
            currentEditingFile = '';
        }

        // Delete file
        async function deleteFile(filePath) {
            if (!confirm('Are you sure you want to delete this file?')) return;
            
            try {
                const response = await fetch(\`/file/\${encodeURIComponent(filePath)}\`, {
                    method: 'DELETE'
                });
                const result = await response.json();
                alert(result.message);
                if (result.success) {
                    loadFiles();
                }
            } catch (error) {
                alert('Delete failed: ' + error.message);
            }
        }

        // Bot control
        async function startBot() {
            try {
                const response = await fetch('/bot/start', { method: 'POST' });
                const result = await response.json();
                alert(result.message);
            } catch (error) {
                alert('Failed to start bot: ' + error.message);
            }
        }

        async function stopBot() {
            try {
                const response = await fetch('/bot/stop', { method: 'POST' });
                const result = await response.json();
                alert(result.message);
            } catch (error) {
                alert('Failed to stop bot: ' + error.message);
            }
        }

        async function restartBot() {
            try {
                const response = await fetch('/bot/restart', { method: 'POST' });
                const result = await response.json();
                alert(result.message);
            } catch (error) {
                alert('Failed to restart bot: ' + error.message);
            }
        }

        // Run command
        async function runCommand() {
            const command = document.getElementById('commandInput').value;
            if (!command) return;
            
            try {
                const response = await fetch('/command', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ command })
                });
                const result = await response.json();
                document.getElementById('commandInput').value = '';
            } catch (error) {
                console.error('Command failed:', error);
            }
        }

        // Load logs
        function loadLogs() {
            fetch('/logs')
                .then(response => response.json())
                .then(logs => {
                    document.getElementById('logs').textContent = logs.join('\\n');
                    document.getElementById('logs').scrollTop = document.getElementById('logs').scrollHeight;
                })
                .catch(console.error);
        }

        // Auto-refresh logs
        setInterval(loadLogs, 2000);

        // Load files on page load
        loadFiles();
    </script>
</body>
</html>
  `);
});

// Upload and extract zip
app.post('/upload', upload.single('botZip'), (req, res) => {
  try {
    if (!req.file) {
      return res.json({ success: false, message: 'No file uploaded' });
    }

    const zipPath = req.file.path;
    const zip = new AdmZip(zipPath);

    // Clear bot directory
    fs.emptyDirSync(BOT_DIR);

    // Extract zip
    zip.extractAllTo(BOT_DIR, true);

    // Clean up uploaded zip
    fs.unlinkSync(zipPath);

    res.json({ success: true, message: 'Bot project uploaded and extracted successfully' });
  } catch (error) {
    res.json({ success: false, message: 'Failed to extract zip: ' + error.message });
  }
});

// Get file list
app.get('/files', (req, res) => {
  try {
    const files = [];
    
    function scanDir(dir, relativePath = '') {
      const items = fs.readdirSync(dir);
      
      items.forEach(item => {
        const fullPath = path.join(dir, item);
        const relPath = path.join(relativePath, item);
        const stat = fs.statSync(fullPath);
        
        files.push({
          path: relPath,
          isFile: stat.isFile(),
          isDirectory: stat.isDirectory()
        });
        
        if (stat.isDirectory()) {
          scanDir(fullPath, relPath);
        }
      });
    }
    
    if (fs.existsSync(BOT_DIR)) {
      scanDir(BOT_DIR);
    }
    
    res.json(files);
  } catch (error) {
    res.json([]);
  }
});

// Get file content
app.get('/file/:filePath(*)', (req, res) => {
  try {
    const filePath = path.join(BOT_DIR, req.params.filePath);
    
    if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
      return res.json({ success: false, message: 'File not found' });
    }
    
    const content = fs.readFileSync(filePath, 'utf8');
    res.json({ success: true, content });
  } catch (error) {
    res.json({ success: false, message: 'Failed to read file: ' + error.message });
  }
});

// Save file content
app.post('/file/:filePath(*)', (req, res) => {
  try {
    const filePath = path.join(BOT_DIR, req.params.filePath);
    const { content } = req.body;
    
    // Ensure directory exists
    fs.ensureDirSync(path.dirname(filePath));
    
    fs.writeFileSync(filePath, content, 'utf8');
    res.json({ success: true, message: 'File saved successfully' });
  } catch (error) {
    res.json({ success: false, message: 'Failed to save file: ' + error.message });
  }
});

// Delete file
app.delete('/file/:filePath(*)', (req, res) => {
  try {
    const filePath = path.join(BOT_DIR, req.params.filePath);
    
    if (fs.existsSync(filePath)) {
      fs.removeSync(filePath);
      res.json({ success: true, message: 'File deleted successfully' });
    } else {
      res.json({ success: false, message: 'File not found' });
    }
  } catch (error) {
    res.json({ success: false, message: 'Failed to delete file: ' + error.message });
  }
});

// Bot control endpoints
app.post('/bot/start', (req, res) => {
  try {
    if (botProcess) {
      return res.json({ success: false, message: 'Bot is already running' });
    }

    const mainFile = path.join(BOT_DIR, 'index.js');
    if (!fs.existsSync(mainFile)) {
      return res.json({ success: false, message: 'Bot main file (index.js) not found' });
    }

    botProcess = spawn('node', [mainFile], {
      cwd: BOT_DIR,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, NODE_ENV: 'production' }
    });

    botProcess.stdout.on('data', (data) => {
      const log = `[STDOUT] ${data.toString()}`;
      botLogs.push(log);
      if (botLogs.length > 1000) botLogs.shift();
    });

    botProcess.stderr.on('data', (data) => {
      const log = `[STDERR] ${data.toString()}`;
      botLogs.push(log);
      if (botLogs.length > 1000) botLogs.shift();
    });

    botProcess.on('close', (code) => {
      const log = `[SYSTEM] Bot process exited with code ${code}`;
      botLogs.push(log);
      botProcess = null;
    });

    res.json({ success: true, message: 'Bot started successfully' });
  } catch (error) {
    res.json({ success: false, message: 'Failed to start bot: ' + error.message });
  }
});

app.post('/bot/stop', (req, res) => {
  try {
    if (!botProcess) {
      return res.json({ success: false, message: 'Bot is not running' });
    }

    botProcess.kill();
    botProcess = null;
    botLogs.push('[SYSTEM] Bot stopped by user');
    
    res.json({ success: true, message: 'Bot stopped successfully' });
  } catch (error) {
    res.json({ success: false, message: 'Failed to stop bot: ' + error.message });
  }
});

app.post('/bot/restart', (req, res) => {
  try {
    if (botProcess) {
      botProcess.kill();
      botProcess = null;
    }

    setTimeout(() => {
      const mainFile = path.join(BOT_DIR, 'index.js');
      if (!fs.existsSync(mainFile)) {
        return res.json({ success: false, message: 'Bot main file (index.js) not found' });
      }

      botProcess = spawn('node', [mainFile], {
        cwd: BOT_DIR,
        stdio: ['pipe', 'pipe', 'pipe'],
        env: { ...process.env, NODE_ENV: 'production' }
      });

      botProcess.stdout.on('data', (data) => {
        const log = `[STDOUT] ${data.toString()}`;
        botLogs.push(log);
        if (botLogs.length > 1000) botLogs.shift();
      });

      botProcess.stderr.on('data', (data) => {
        const log = `[STDERR] ${data.toString()}`;
        botLogs.push(log);
        if (botLogs.length > 1000) botLogs.shift();
      });

      botProcess.on('close', (code) => {
        const log = `[SYSTEM] Bot process exited with code ${code}`;
        botLogs.push(log);
        botProcess = null;
      });

      botLogs.push('[SYSTEM] Bot restarted by user');
    }, 1000);

    res.json({ success: true, message: 'Bot restarted successfully' });
  } catch (error) {
    res.json({ success: false, message: 'Failed to restart bot: ' + error.message });
  }
});

// Run custom command
app.post('/command', (req, res) => {
  try {
    const { command } = req.body;
    
    exec(command, { cwd: BOT_DIR }, (error, stdout, stderr) => {
      if (error) {
        botLogs.push(`[COMMAND ERROR] ${error.message}`);
      }
      if (stdout) {
        botLogs.push(`[COMMAND OUT] ${stdout}`);
      }
      if (stderr) {
        botLogs.push(`[COMMAND ERR] ${stderr}`);
      }
      
      if (botLogs.length > 1000) {
        botLogs = botLogs.slice(-1000);
      }
    });

    res.json({ success: true, message: 'Command executed' });
  } catch (error) {
    res.json({ success: false, message: 'Failed to run command: ' + error.message });
  }
});

// Health check endpoint for AWS
app.get('/health', (req, res) => {
  res.status(200).json({ 
    status: 'healthy', 
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    botRunning: !!botProcess
  });
});

// Get logs
app.get('/logs', (req, res) => {
  res.json(botLogs);
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Bot Panel running on port ${PORT}`);
  console.log(`Access it at: http://0.0.0.0:${PORT}`);
  console.log(`AWS Compatible: Server listening on all interfaces`);
});
